// ============================================================
// FUEL PRO SERVICE WORKER v1
// Offline caching, background sync, stale-while-revalidate
// ============================================================

const CACHE_NAME = 'fuelpro-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
];

// Install: cache static shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    }).then(() => {
      self.skipWaiting();
    })
  );
});

// Activate: clean old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) => {
      return Promise.all(
        names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
      );
    }).then(() => {
      self.clients.claim();
    })
  );
});

// Fetch: stale-while-revalidate strategy
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== 'GET') return;

  // Skip external requests
  if (url.origin !== self.location.origin) return;

  // API calls: network first with cache fallback
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          return response;
        })
        .catch(() => caches.match(request))
    );
    return;
  }

  // Static assets: cache first, network fallback
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) {
        // Background refresh
        fetch(request).then((response) => {
          caches.open(CACHE_NAME).then((cache) => cache.put(request, response));
        }).catch(() => {});
        return cached;
      }
      return fetch(request).then((response) => {
        if (response.ok && response.type === 'basic') {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        return response;
      });
    })
  );
});

// Background sync for failed operations
self.addEventListener('sync', (event) => {
  if (event.tag === 'fuelpro-sync') {
    event.waitUntil(syncPendingOperations());
  }
});

async function syncPendingOperations() {
  const cache = await caches.open(CACHE_NAME);
  const pendingReq = await cache.match('pending-ops');
  if (pendingReq) {
    const ops = await pendingReq.json();
    for (const op of ops) {
      try {
        await fetch(op.url, { method: op.method, body: JSON.stringify(op.body) });
      } catch (e) {
        console.error('[SW] Sync failed for', op.url, e);
      }
    }
    await cache.delete('pending-ops');
  }
}

// Push notifications (future)
self.addEventListener('push', (event) => {
  if (!event.data) return;
  const data = event.data.json();
  event.waitUntil(
    self.registration.showNotification(data.title || 'FuelPro', {
      body: data.body || 'New notification',
      icon: '/icon-192.png',
      badge: '/badge-72.png',
      data: data.url || '/',
    })
  );
});

// Message handling from main thread
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
