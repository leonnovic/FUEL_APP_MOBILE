// ============================================================
// REGIONAL REGULATORY CONFIGURATIONS
// Country-specific compliance, tax, and operational settings
// ============================================================

export interface RegionalConfig {
  country: string;
  countryCode: string;
  currency: string;
  currencySymbol: string;
  taxAuthority: string;
  taxAuthorityShort: string;
  vatRate: number;
  vatName: string;
  hasETR: boolean;
  etrName: string;
  etrFormat: string;
  fuelRegulator: string;
  fuelRegulatorShort: string;
  fuelTypes: FuelTypeConfig[];
  requiredPermits: string[];
  reportingFrequency: string;
  receiptRequirements: string[];
  complianceFeatures: ComplianceFeature[];
  holidays: string[];
  dateFormat: string;
  timeZone: string;
  decimalSeparator: string;
  thousandSeparator: string;
  units: { volume: string; distance: string; temperature: string };
  languages: string[];
  phoneCode: string;
  bankSupport: BankConfig[];
  paymentMethods: PaymentMethod[];
}

interface FuelTypeConfig {
  code: string;
  name: string;
  localName: string;
  taxRate: number;
  levyRate: number;
  regulatoryBody: string;
}

interface ComplianceFeature {
  id: string;
  name: string;
  description: string;
  required: boolean;
  category: string;
}

interface BankConfig {
  code: string;
  name: string;
  supportsApi: boolean;
  supportsStatementImport: boolean;
}

interface PaymentMethod {
  id: string;
  name: string;
  type: 'mobile' | 'card' | 'bank' | 'cash' | 'other';
  provider?: string;
  chargeRate: number;
}

export const REGIONAL_CONFIGS: Record<string, RegionalConfig> = {
  kenya: {
    country: 'Kenya',
    countryCode: 'KE',
    currency: 'Kenyan Shilling',
    currencySymbol: 'Ksh',
    taxAuthority: 'Kenya Revenue Authority',
    taxAuthorityShort: 'KRA',
    vatRate: 16,
    vatName: 'VAT',
    hasETR: true,
    etrName: 'eTIMS Electronic Tax Invoice',
    etrFormat: 'JSON API + QR Code',
    fuelRegulator: 'Energy and Petroleum Regulatory Authority',
    fuelRegulatorShort: 'EPRA',
    fuelTypes: [
      { code: 'PMS', name: 'Premium Motor Spirit', localName: 'Petrol (Super)', taxRate: 0, levyRate: 0, regulatoryBody: 'EPRA' },
      { code: 'AGO', name: 'Automotive Gas Oil', localName: 'Diesel', taxRate: 0, levyRate: 0, regulatoryBody: 'EPRA' },
      { code: 'IK', name: 'Illuminating Kerosene', localName: 'Kerosene', taxRate: 0, levyRate: 0, regulatoryBody: 'EPRA' },
      { code: 'LPG', name: 'Liquefied Petroleum Gas', localName: 'Cooking Gas', taxRate: 8, levyRate: 0, regulatoryBody: 'EPRA' },
    ],
    requiredPermits: [
      'EPRA Retail License',
      'KRA VAT Registration',
      'eTIMS Registration',
      'County Business Permit',
      'Nema Environmental License',
      'Fire Safety Certificate',
      'Weights & Measures License',
      'NCA Structural Certificate',
    ],
    reportingFrequency: 'monthly',
    receiptRequirements: [
      'eTIMS QR Code',
      'KRA PIN of station',
      'Invoice number',
      'Date and time',
      'Item description and quantity',
      'Unit price and total',
      'VAT amount',
    ],
    complianceFeatures: [
      { id: 'kra-etims', name: 'KRA eTIMS Integration', description: 'Generate electronic tax invoices with QR codes', required: true, category: 'Tax' },
      { id: 'epra-pricing', name: 'EPRA Price Compliance', description: 'Monitor pump prices against EPRA guidelines', required: true, category: 'Pricing' },
      { id: 'monthly-vat', name: 'Monthly VAT Returns', description: 'Automated VAT iTax filing preparation', required: true, category: 'Tax' },
      { id: 'levy-tracking', name: 'Anti-Adulteration Levy', description: 'Track and report fuel adulteration levy', required: true, category: 'Tax' },
      { id: 'road-maintenance', name: 'Road Maintenance Levy', description: 'Calculate and report RML collections', required: true, category: 'Tax' },
      { id: 'petroleum-vat', name: 'Petroleum Development VAT', description: 'Track petroleum VAT submissions', required: true, category: 'Tax' },
      { id: 'environmental', name: 'Environmental Compliance', description: 'Waste oil disposal and NEMA reporting', required: true, category: 'Environment' },
      { id: 'weights-measures', name: 'Weights & Measures', description: 'Calibration tracking for pump accuracy', required: true, category: 'Quality' },
    ],
    holidays: ['Madaraka Day (June 1)', 'Mashujaa Day (Oct 20)', 'Jamhuri Day (Dec 12)', 'Huduma Day (Oct 10)'],
    dateFormat: 'DD/MM/YYYY',
    timeZone: 'Africa/Nairobi',
    decimalSeparator: '.',
    thousandSeparator: ',',
    units: { volume: 'Litres', distance: 'Kilometres', temperature: 'Celsius' },
    languages: ['English', 'Kiswahili'],
    phoneCode: '+254',
    bankSupport: [
      { code: 'kcb', name: 'KCB Bank', supportsApi: true, supportsStatementImport: true },
      { code: 'equity', name: 'Equity Bank', supportsApi: true, supportsStatementImport: true },
      { code: 'coop', name: 'Co-operative Bank', supportsApi: true, supportsStatementImport: true },
      { code: 'ncba', name: 'NCBA Bank', supportsApi: false, supportsStatementImport: true },
      { code: 'absa', name: 'Absa Bank Kenya', supportsApi: false, supportsStatementImport: true },
    ],
    paymentMethods: [
      { id: 'mpesa', name: 'M-PESA', type: 'mobile', provider: 'Safaricom', chargeRate: 0 },
      { id: 'airtel-money', name: 'Airtel Money', type: 'mobile', provider: 'Airtel', chargeRate: 0 },
      { id: 'bank-transfer', name: 'Bank Transfer', type: 'bank', chargeRate: 0 },
      { id: 'card', name: 'Debit/Credit Card', type: 'card', chargeRate: 1.5 },
      { id: 'cash', name: 'Cash', type: 'cash', chargeRate: 0 },
    ],
  },
  uganda: {
    country: 'Uganda',
    countryCode: 'UG',
    currency: 'Ugandan Shilling',
    currencySymbol: 'USh',
    taxAuthority: 'Uganda Revenue Authority',
    taxAuthorityShort: 'URA',
    vatRate: 18,
    vatName: 'VAT',
    hasETR: true,
    etrName: 'EFRIS Electronic Fiscal Receipt',
    etrFormat: 'JSON API + Fiscal Signature',
    fuelRegulator: 'Ministry of Energy and Mineral Development',
    fuelRegulatorShort: 'MEMD',
    fuelTypes: [
      { code: 'PMS', name: 'Premium Motor Spirit', localName: 'Petrol', taxRate: 0, levyRate: 0, regulatoryBody: 'MEMD' },
      { code: 'AGO', name: 'Automotive Gas Oil', localName: 'Diesel', taxRate: 0, levyRate: 0, regulatoryBody: 'MEMD' },
      { code: 'IK', name: 'Illuminating Kerosene', localName: 'Kerosene', taxRate: 0, levyRate: 0, regulatoryBody: 'MEMD' },
    ],
    requiredPermits: [
      'MEMD Fuel Retail License',
      'URA VAT/TIN Registration',
      'EFRIS Registration',
      'Trading License',
      'UNBS Quality Certificate',
      'Environmental Certificate',
    ],
    reportingFrequency: 'monthly',
    receiptRequirements: [
      'EFRIS fiscal signature',
      'URA TIN of station',
      'Invoice number',
      'Date and time',
      'VAT amount breakdown',
    ],
    complianceFeatures: [
      { id: 'ura-efris', name: 'URA EFRIS Integration', description: 'Generate EFRIS fiscal receipts', required: true, category: 'Tax' },
      { id: 'unbs-quality', name: 'UNBS Quality Mark', description: 'Track fuel quality standards compliance', required: true, category: 'Quality' },
      { id: 'memd-pricing', name: 'MEMD Price Controls', description: 'Monitor against regulated pump prices', required: true, category: 'Pricing' },
      { id: 'excise-duty', name: 'Excise Duty Reporting', description: 'Fuel excise duty tracking and reporting', required: true, category: 'Tax' },
      { id: 'environmental-ug', name: 'NEMA Uganda Compliance', description: 'Environmental management compliance', required: true, category: 'Environment' },
    ],
    holidays: ['Independence Day (Oct 9)', 'Heroes Day (June 9)', 'Martyrs Day (June 3)'],
    dateFormat: 'DD/MM/YYYY',
    timeZone: 'Africa/Kampala',
    decimalSeparator: '.',
    thousandSeparator: ',',
    units: { volume: 'Litres', distance: 'Kilometres', temperature: 'Celsius' },
    languages: ['English', 'Swahili', 'Luganda'],
    phoneCode: '+256',
    bankSupport: [
      { code: 'stanbic-ug', name: 'Stanbic Bank Uganda', supportsApi: true, supportsStatementImport: true },
      { code: 'centenary', name: 'Centenary Bank', supportsApi: false, supportsStatementImport: true },
    ],
    paymentMethods: [
      { id: 'mtn-momo', name: 'MTN Mobile Money', type: 'mobile', provider: 'MTN', chargeRate: 0 },
      { id: 'airtel-money-ug', name: 'Airtel Money', type: 'mobile', provider: 'Airtel', chargeRate: 0 },
      { id: 'cash', name: 'Cash', type: 'cash', chargeRate: 0 },
    ],
  },
  tanzania: {
    country: 'Tanzania',
    countryCode: 'TZ',
    currency: 'Tanzanian Shilling',
    currencySymbol: 'TSh',
    taxAuthority: 'Tanzania Revenue Authority',
    taxAuthorityShort: 'TRA',
    vatRate: 18,
    vatName: 'VAT',
    hasETR: true,
    etrName: 'Electronic Fiscal Device (EFD)',
    etrFormat: 'XML + VFD Display',
    fuelRegulator: 'Energy and Water Utilities Regulatory Authority',
    fuelRegulatorShort: 'EWURA',
    fuelTypes: [
      { code: 'PMS', name: 'Premium Motor Spirit', localName: 'Petrol', taxRate: 0, levyRate: 0, regulatoryBody: 'EWURA' },
      { code: 'AGO', name: 'Automotive Gas Oil', localName: 'Diesel', taxRate: 0, levyRate: 0, regulatoryBody: 'EWURA' },
      { code: 'IK', name: 'Illuminating Kerosene', localName: 'Kerosene', taxRate: 0, levyRate: 0, regulatoryBody: 'EWURA' },
    ],
    requiredPermits: [
      'EWURA Retail License',
      'TRA TIN Registration',
      'EFD Registration',
      'Business License',
      'TBS Quality Certificate',
    ],
    reportingFrequency: 'monthly',
    receiptRequirements: [
      'EFD generated receipt',
      'TRA TIN',
      'Fiscal receipt number',
      'Date and time',
      'VAT breakdown',
    ],
    complianceFeatures: [
      { id: 'tra-efd', name: 'TRA EFD Integration', description: 'Connect Electronic Fiscal Device', required: true, category: 'Tax' },
      { id: 'ewura-pricing', name: 'EWURA Price Caps', description: 'Monitor pump prices against EWURA caps', required: true, category: 'Pricing' },
      { id: 'tbs-quality', name: 'TBS Fuel Standards', description: 'Track Tanzania Bureau of Standards compliance', required: true, category: 'Quality' },
      { id: 'fuel-levy-tz', name: 'Fuel Levy Collection', description: 'Track petroleum levy submissions', required: true, category: 'Tax' },
    ],
    holidays: ['Independence Day (Dec 9)', 'Union Day (Apr 26)', 'Saba Saba (July 7)'],
    dateFormat: 'DD/MM/YYYY',
    timeZone: 'Africa/Dar_es_Salaam',
    decimalSeparator: '.',
    thousandSeparator: ',',
    units: { volume: 'Litres', distance: 'Kilometres', temperature: 'Celsius' },
    languages: ['Swahili', 'English'],
    phoneCode: '+255',
    bankSupport: [
      { code: 'crdb', name: 'CRDB Bank', supportsApi: true, supportsStatementImport: true },
      { code: 'nmb', name: 'NMB Bank', supportsApi: false, supportsStatementImport: true },
    ],
    paymentMethods: [
      { id: 'mpesa-tz', name: 'M-PESA', type: 'mobile', provider: 'Vodacom', chargeRate: 0 },
      { id: 'tigo-pesa', name: 'Tigo Pesa', type: 'mobile', provider: 'Tigo', chargeRate: 0 },
      { id: 'airtel-money-tz', name: 'Airtel Money', type: 'mobile', provider: 'Airtel', chargeRate: 0 },
      { id: 'cash', name: 'Cash', type: 'cash', chargeRate: 0 },
    ],
  },
  nigeria: {
    country: 'Nigeria',
    countryCode: 'NG',
    currency: 'Nigerian Naira',
    currencySymbol: '\u20A6',
    taxAuthority: 'Federal Inland Revenue Service',
    taxAuthorityShort: 'FIRS',
    vatRate: 7.5,
    vatName: 'VAT',
    hasETR: false,
    etrName: 'Tax Invoice',
    etrFormat: 'Standard Invoice',
    fuelRegulator: 'Petroleum Products Pricing Regulatory Agency',
    fuelRegulatorShort: 'PPPRA',
    fuelTypes: [
      { code: 'PMS', name: 'Premium Motor Spirit', localName: 'Petrol', taxRate: 7.5, levyRate: 0, regulatoryBody: 'PPPRA' },
      { code: 'AGO', name: 'Automotive Gas Oil', localName: 'Diesel', taxRate: 7.5, levyRate: 0, regulatoryBody: 'PPPRA' },
      { code: 'DPK', name: 'Dual Purpose Kerosene', localName: 'Kerosene', taxRate: 7.5, levyRate: 0, regulatoryBody: 'PPPRA' },
      { code: 'LPG', name: 'Liquefied Petroleum Gas', localName: 'Cooking Gas', taxRate: 7.5, levyRate: 0, regulatoryBody: 'PPPRA' },
    ],
    requiredPermits: [
      'DPR Retail License',
      'FIRS TIN Registration',
      'State Business Permit',
      'Fire Service Certificate',
      'Environmental Impact Assessment',
    ],
    reportingFrequency: 'monthly',
    receiptRequirements: [
      'Tax invoice number',
      'FIRS TIN',
      'Date and time',
      'VAT amount',
      'Total amount',
    ],
    complianceFeatures: [
      { id: 'firs-tax', name: 'FIRS Tax Filing', description: 'Monthly VAT and withholding tax filing', required: true, category: 'Tax' },
      { id: 'pppra-pricing', name: 'PPPRA Price Template', description: 'Monitor against PPPRA pricing template', required: true, category: 'Pricing' },
      { id: 'son-quality', name: 'SON Standards', description: 'Track Standards Organisation of Nigeria compliance', required: true, category: 'Quality' },
    ],
    holidays: ['Independence Day (Oct 1)', 'Democracy Day (June 12)'],
    dateFormat: 'DD/MM/YYYY',
    timeZone: 'Africa/Lagos',
    decimalSeparator: '.',
    thousandSeparator: ',',
    units: { volume: 'Litres', distance: 'Kilometres', temperature: 'Celsius' },
    languages: ['English', 'Hausa', 'Yoruba', 'Igbo'],
    phoneCode: '+234',
    bankSupport: [
      { code: 'gtbank', name: 'GTBank', supportsApi: true, supportsStatementImport: true },
      { code: 'zenith', name: 'Zenith Bank', supportsApi: true, supportsStatementImport: true },
    ],
    paymentMethods: [
      { id: 'cash', name: 'Cash', type: 'cash', chargeRate: 0 },
      { id: 'pos-ng', name: 'POS Terminal', type: 'card', chargeRate: 0.5 },
      { id: 'bank-transfer', name: 'Bank Transfer', type: 'bank', chargeRate: 0 },
    ],
  },
  southafrica: {
    country: 'South Africa',
    countryCode: 'ZA',
    currency: 'South African Rand',
    currencySymbol: 'R',
    taxAuthority: 'South African Revenue Service',
    taxAuthorityShort: 'SARS',
    vatRate: 15,
    vatName: 'VAT',
    hasETR: true,
    etrName: 'VAT Invoice',
    etrFormat: 'Standard VAT Invoice',
    fuelRegulator: 'Department of Mineral Resources and Energy',
    fuelRegulatorShort: 'DMRE',
    fuelTypes: [
      { code: 'ULP', name: 'Unleaded Petrol', localName: 'Petrol 93/95', taxRate: 0, levyRate: 0, regulatoryBody: 'DMRE' },
      { code: 'DIESEL', name: 'Diesel', localName: 'Diesel 50ppm', taxRate: 0, levyRate: 0, regulatoryBody: 'DMRE' },
      { code: 'LPG', name: 'Liquefied Petroleum Gas', localName: 'LPG', taxRate: 0, levyRate: 0, regulatoryBody: 'DMRE' },
    ],
    requiredPermits: [
      'DMRE Wholesale License',
      'SARS VAT Registration',
      'Municipal Business License',
      'Fire Safety Certificate',
      'Environmental Authorization',
    ],
    reportingFrequency: 'bi-monthly',
    receiptRequirements: [
      'VAT invoice with SARS VAT number',
      'Invoice number',
      'Date and time',
      'Item description',
      'VAT amount and rate',
    ],
    complianceFeatures: [
      { id: 'sars-vat', name: 'SARS VAT201 Filing', description: 'Bi-monthly VAT201 return filing', required: true, category: 'Tax' },
      { id: 'dmre-pricing', name: 'DMRE Fuel Pricing', description: 'Monthly fuel price structure compliance', required: true, category: 'Pricing' },
      { id: 'road-accident', name: 'RAF Levy', description: 'Road Accident Fund levy tracking', required: true, category: 'Tax' },
      { id: 'fuel-levy-sa', name: 'General Fuel Levy', description: 'Track fuel levy and customs excise', required: true, category: 'Tax' },
    ],
    holidays: ['Heritage Day (Sept 24)', 'Freedom Day (Apr 27)', 'Youth Day (June 16)'],
    dateFormat: 'YYYY-MM-DD',
    timeZone: 'Africa/Johannesburg',
    decimalSeparator: '.',
    thousandSeparator: ' ',
    units: { volume: 'Litres', distance: 'Kilometres', temperature: 'Celsius' },
    languages: ['English', 'Afrikaans', 'Zulu', 'Xhosa'],
    phoneCode: '+27',
    bankSupport: [
      { code: 'fnb', name: 'First National Bank', supportsApi: true, supportsStatementImport: true },
      { code: 'standard-bank', name: 'Standard Bank', supportsApi: true, supportsStatementImport: true },
      { code: 'absa-sa', name: 'Absa', supportsApi: true, supportsStatementImport: true },
    ],
    paymentMethods: [
      { id: 'snapscan', name: 'SnapScan', type: 'mobile', provider: 'SnapScan', chargeRate: 0 },
      { id: 'card', name: 'Debit/Credit Card', type: 'card', chargeRate: 0 },
      { id: 'cash', name: 'Cash', type: 'cash', chargeRate: 0 },
      { id: 'eft', name: 'EFT', type: 'bank', chargeRate: 0 },
    ],
  },
  ghana: {
    country: 'Ghana',
    countryCode: 'GH',
    currency: 'Ghanaian Cedi',
    currencySymbol: 'GH\u20B5',
    taxAuthority: 'Ghana Revenue Authority',
    taxAuthorityShort: 'GRA',
    vatRate: 15,
    vatName: 'VAT',
    hasETR: false,
    etrName: 'VAT Invoice',
    etrFormat: 'Standard Invoice',
    fuelRegulator: 'National Petroleum Authority',
    fuelRegulatorShort: 'NPA',
    fuelTypes: [
      { code: 'PMS', name: 'Premium Motor Spirit', localName: 'Petrol', taxRate: 0, levyRate: 0, regulatoryBody: 'NPA' },
      { code: 'AGO', name: 'Automotive Gas Oil', localName: 'Diesel', taxRate: 0, levyRate: 0, regulatoryBody: 'NPA' },
      { code: 'LPG', name: 'Liquefied Petroleum Gas', localName: 'LPG', taxRate: 0, levyRate: 0, regulatoryBody: 'NPA' },
    ],
    requiredPermits: [
      'NPA Retail License',
      'GRA VAT/TIN Registration',
      'Business Operating Permit',
      'EPA Environmental Permit',
    ],
    reportingFrequency: 'monthly',
    receiptRequirements: [
      'VAT invoice with TIN',
      'Date and time',
      'VAT amount',
      'Total amount',
    ],
    complianceFeatures: [
      { id: 'gra-vat', name: 'GRA VAT Filing', description: 'Monthly VAT return filing', required: true, category: 'Tax' },
      { id: 'npa-pricing', name: 'NPA Price Monitoring', description: 'Track against NPA price ceilings', required: true, category: 'Pricing' },
      { id: 'energy-levy', name: 'Energy Sector Levy', description: 'ESLA levy tracking and reporting', required: true, category: 'Tax' },
    ],
    holidays: ['Independence Day (Mar 6)', 'Founders Day (Sept 21)'],
    dateFormat: 'DD/MM/YYYY',
    timeZone: 'Africa/Accra',
    decimalSeparator: '.',
    thousandSeparator: ',',
    units: { volume: 'Litres', distance: 'Kilometres', temperature: 'Celsius' },
    languages: ['English', 'Twi', 'Ga', 'Ewe'],
    phoneCode: '+233',
    bankSupport: [
      { code: 'ecobank', name: 'Ecobank', supportsApi: false, supportsStatementImport: true },
      { code: 'gcb', name: 'GCB Bank', supportsApi: false, supportsStatementImport: true },
    ],
    paymentMethods: [
      { id: 'mtn-momo-gh', name: 'MTN MoMo', type: 'mobile', provider: 'MTN', chargeRate: 0 },
      { id: 'vodafone-cash', name: 'Vodafone Cash', type: 'mobile', provider: 'Vodafone', chargeRate: 0 },
      { id: 'cash', name: 'Cash', type: 'cash', chargeRate: 0 },
    ],
  },
  rwanda: {
    country: 'Rwanda',
    countryCode: 'RW',
    currency: 'Rwandan Franc',
    currencySymbol: 'FRw',
    taxAuthority: 'Rwanda Revenue Authority',
    taxAuthorityShort: 'RRA',
    vatRate: 18,
    vatName: 'VAT',
    hasETR: true,
    etrName: 'EBM (Electronic Billing Machine)',
    etrFormat: 'EBM Generated Receipt',
    fuelRegulator: 'Rwanda Utilities Regulatory Authority',
    fuelRegulatorShort: 'RURA',
    fuelTypes: [
      { code: 'PMS', name: 'Premium Motor Spirit', localName: 'Petrol', taxRate: 0, levyRate: 0, regulatoryBody: 'RURA' },
      { code: 'AGO', name: 'Automotive Gas Oil', localName: 'Diesel', taxRate: 0, levyRate: 0, regulatoryBody: 'RURA' },
    ],
    requiredPermits: [
      'RURA License',
      'RRA TIN Registration',
      'EBM Registration',
      'Trading License',
    ],
    reportingFrequency: 'monthly',
    receiptRequirements: [
      'EBM receipt',
      'RRA TIN',
      'Date and time',
      'VAT amount',
    ],
    complianceFeatures: [
      { id: 'rra-ebm', name: 'RRA EBM Integration', description: 'Connect Electronic Billing Machine', required: true, category: 'Tax' },
      { id: 'rura-pricing', name: 'RURA Fuel Pricing', description: 'Monitor against RURA price caps', required: true, category: 'Pricing' },
    ],
    holidays: ['Independence Day (July 1)', 'Liberation Day (July 4)'],
    dateFormat: 'DD/MM/YYYY',
    timeZone: 'Africa/Kigali',
    decimalSeparator: '.',
    thousandSeparator: ',',
    units: { volume: 'Litres', distance: 'Kilometres', temperature: 'Celsius' },
    languages: ['Kinyarwanda', 'English', 'French'],
    phoneCode: '+250',
    bankSupport: [
      { code: 'bk', name: 'Bank of Kigali', supportsApi: false, supportsStatementImport: true },
    ],
    paymentMethods: [
      { id: 'mtn-momo-rw', name: 'MTN MoMo', type: 'mobile', provider: 'MTN', chargeRate: 0 },
      { id: 'airtel-money-rw', name: 'Airtel Money', type: 'mobile', provider: 'Airtel', chargeRate: 0 },
      { id: 'cash', name: 'Cash', type: 'cash', chargeRate: 0 },
    ],
  },
  ethiopia: {
    country: 'Ethiopia',
    countryCode: 'ET',
    currency: 'Ethiopian Birr',
    currencySymbol: 'Br',
    taxAuthority: 'Ethiopian Revenue and Customs Authority',
    taxAuthorityShort: 'ERCA',
    vatRate: 15,
    vatName: 'VAT',
    hasETR: false,
    etrName: 'Tax Invoice',
    etrFormat: 'Standard Invoice',
    fuelRegulator: 'Ethiopian Petroleum Supply Enterprise',
    fuelRegulatorShort: 'EPSE',
    fuelTypes: [
      { code: 'PMS', name: 'Premium Motor Spirit', localName: 'Benzene', taxRate: 0, levyRate: 0, regulatoryBody: 'EPSE' },
      { code: 'AGO', name: 'Automotive Gas Oil', localName: 'Diesel', taxRate: 0, levyRate: 0, regulatoryBody: 'EPSE' },
      { code: 'IK', name: 'Illuminating Kerosene', localName: 'Kerosene', taxRate: 0, levyRate: 0, regulatoryBody: 'EPSE' },
    ],
    requiredPermits: [
      'EPSE Distribution License',
      'ERCA VAT/TIN Registration',
      'Trade License',
      'Environmental Certificate',
    ],
    reportingFrequency: 'monthly',
    receiptRequirements: [
      'Tax invoice',
      'Date and time',
      'VAT amount',
      'Total amount',
    ],
    complianceFeatures: [
      { id: 'erca-vat', name: 'ERCA VAT Filing', description: 'Monthly VAT return filing', required: true, category: 'Tax' },
      { id: 'epse-pricing', name: 'EPSE Price Control', description: 'Government-controlled fuel pricing', required: true, category: 'Pricing' },
    ],
    holidays: ['Victory Day (May 5)', 'Enkutatash (Sept 11)'],
    dateFormat: 'DD/MM/YYYY',
    timeZone: 'Africa/Addis_Ababa',
    decimalSeparator: '.',
    thousandSeparator: ',',
    units: { volume: 'Litres', distance: 'Kilometres', temperature: 'Celsius' },
    languages: ['Amharic', 'English', 'Oromo'],
    phoneCode: '+251',
    bankSupport: [
      { code: 'cbe', name: 'Commercial Bank of Ethiopia', supportsApi: false, supportsStatementImport: true },
    ],
    paymentMethods: [
      { id: 'telebirr', name: 'Telebirr', type: 'mobile', provider: 'Ethio Telecom', chargeRate: 0 },
      { id: 'cash', name: 'Cash', type: 'cash', chargeRate: 0 },
    ],
  },
};

export function getRegionalConfig(countryKey: string): RegionalConfig {
  return REGIONAL_CONFIGS[countryKey.toLowerCase()] || REGIONAL_CONFIGS.kenya;
}

export function getAllCountries(): { key: string; name: string; code: string }[] {
  return Object.entries(REGIONAL_CONFIGS).map(([key, config]) => ({
    key,
    name: config.country,
    code: config.countryCode,
  }));
}
