export type PaymentMethodType = 'bank' | 'card' | 'digital_wallet' | 'local_transfer' | 'cash' | 'other';

export interface PaymentMethod {
  id: string;
  name: string;
  type: PaymentMethodType;
  supportedCurrencies: string[];
  isActive: boolean;
}

export interface CountryPaymentConfig {
  countryCode: string;
  countryName: string;
  defaultCurrency: string;
  paymentMethods: PaymentMethod[];
}

export const WORLD_PAYMENT_CONFIGS: Record<string, CountryPaymentConfig> = {
  AD: { countryCode:'AD', countryName:'Andorra', defaultCurrency:'EUR', paymentMethods:[
    {id:'ad_cr', name:'Crèdit Andorrà', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'ad_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'ad_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'ad_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'ad_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  AE: { countryCode:'AE', countryName:'UAE', defaultCurrency:'AED', paymentMethods:[
    {id:'ae_enbd', name:'Emirates NBD', type:'bank', supportedCurrencies:['AED'], isActive:true},
    {id:'ae_mashreq', name:'Mashreq Bank', type:'bank', supportedCurrencies:['AED'], isActive:true},
    {id:'ae_benefits', name:'Benefit Pay / mPay', type:'digital_wallet', supportedCurrencies:['AED'], isActive:true},
    {id:'ae_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AED'], isActive:true},
    {id:'ae_ipg', name:'UAE Network IPG', type:'local_transfer', supportedCurrencies:['AED'], isActive:true}
  ]},
  AF: { countryCode:'AF', countryName:'Afghanistan', defaultCurrency:'AFN', paymentMethods:[
    {id:'af_da_azi', name:'Da Afghanistan Bank', type:'bank', supportedCurrencies:['AFN'], isActive:true},
    {id:'af_ais', name:'AIS Mobile Money', type:'digital_wallet', supportedCurrencies:['AFN'], isActive:true},
    {id:'af_hawala', name:'Hawala Network', type:'local_transfer', supportedCurrencies:['AFN'], isActive:true},
    {id:'af_visa', name:'Visa', type:'card', supportedCurrencies:['USD','AFN'], isActive:true},
    {id:'af_cash_afn', name:'Cash (AFN)', type:'cash', supportedCurrencies:['AFN'], isActive:true}
  ]},
  AG: { countryCode:'AG', countryName:'Antigua & Barbuda', defaultCurrency:'XCD', paymentMethods:[
    {id:'ag_ncb', name:'NCB Antigua', type:'bank', supportedCurrencies:['XCD'], isActive:true},
    {id:'ag_ecash', name:'ECCU eCash', type:'digital_wallet', supportedCurrencies:['XCD'], isActive:true},
    {id:'ag_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XCD','USD'], isActive:true},
    {id:'ag_wire', name:'Eastern Caribbean Wire', type:'local_transfer', supportedCurrencies:['XCD'], isActive:true},
    {id:'ag_cash', name:'Cash (XCD)', type:'cash', supportedCurrencies:['XCD'], isActive:true}
  ]},
  AI: { countryCode:'AI', countryName:'Anguilla', defaultCurrency:'XCD', paymentMethods:[
    {id:'ai_rbtt', name:'RBTT Bank', type:'bank', supportedCurrencies:['XCD'], isActive:true},
    {id:'ai_ecash', name:'ECCU eCash', type:'digital_wallet', supportedCurrencies:['XCD'], isActive:true},
    {id:'ai_visa', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XCD','USD'], isActive:true},
    {id:'ai_ecs', name:'ECS Transfer', type:'local_transfer', supportedCurrencies:['XCD'], isActive:true},
    {id:'ai_cash', name:'Cash (XCD)', type:'cash', supportedCurrencies:['XCD'], isActive:true}
  ]},
  AL: { countryCode:'AL', countryName:'Albania', defaultCurrency:'ALL', paymentMethods:[
    {id:'al_bkt', name:'Banka Kombëtare Tregtare', type:'bank', supportedCurrencies:['ALL'], isActive:true},
    {id:'al_paysera', name:'Paysera', type:'digital_wallet', supportedCurrencies:['ALL','EUR'], isActive:true},
    {id:'al_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['ALL','EUR'], isActive:true},
    {id:'al_ipay', name:'iPay Albania', type:'local_transfer', supportedCurrencies:['ALL'], isActive:true},
    {id:'al_cash', name:'Cash (ALL)', type:'cash', supportedCurrencies:['ALL'], isActive:true}
  ]},
  AM: { countryCode:'AM', countryName:'Armenia', defaultCurrency:'AMD', paymentMethods:[
    {id:'am_acba', name:'ACBA Bank', type:'bank', supportedCurrencies:['AMD'], isActive:true},
    {id:'am_telcell', name:'TelCell Wallet', type:'digital_wallet', supportedCurrencies:['AMD'], isActive:true},
    {id:'am_idram', name:'IDram', type:'digital_wallet', supportedCurrencies:['AMD'], isActive:true},
    {id:'am_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AMD'], isActive:true},
    {id:'am_fast', name:'ArCa Fast Transfer', type:'local_transfer', supportedCurrencies:['AMD'], isActive:true}
  ]},
  AO: { countryCode:'AO', countryName:'Angola', defaultCurrency:'AOA', paymentMethods:[
    {id:'ao_bai', name:'BAI', type:'bank', supportedCurrencies:['AOA'], isActive:true},
    {id:'ao_multicaixa', name:'Multicaixa Express', type:'digital_wallet', supportedCurrencies:['AOA'], isActive:true},
    {id:'ao_unitel_money', name:'Unitel Money', type:'digital_wallet', supportedCurrencies:['AOA'], isActive:true},
    {id:'ao_visa', name:'Visa', type:'card', supportedCurrencies:['AOA','USD'], isActive:true},
    {id:'ao_transf', name:'Multicaixa Transfer', type:'local_transfer', supportedCurrencies:['AOA'], isActive:true}
  ]},
  AQ: { countryCode:'AQ', countryName:'Antarctica', defaultCurrency:'USD', paymentMethods:[
    {id:'aq_usd_bank', name:'USD Bank Transfer', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'aq_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'aq_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'aq_wire', name:'International Wire', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'aq_cash_usd', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  AR: { countryCode:'AR', countryName:'Argentina', defaultCurrency:'ARS', paymentMethods:[
    {id:'ar_banco_nacion', name:'Banco Nación', type:'bank', supportedCurrencies:['ARS'], isActive:true},
    {id:'ar_mercadopago', name:'Mercado Pago', type:'digital_wallet', supportedCurrencies:['ARS'], isActive:true},
    {id:'ar_ualá', name:'Ualá', type:'digital_wallet', supportedCurrencies:['ARS'], isActive:true},
    {id:'ar_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['ARS'], isActive:true},
    {id:'ar_cobro', name:'CBU/CVU Transfer', type:'local_transfer', supportedCurrencies:['ARS'], isActive:true}
  ]},
  AS: { countryCode:'AS', countryName:'American Samoa', defaultCurrency:'USD', paymentMethods:[
    {id:'as_bofa', name:'Bank of Hawaii / US Banks', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'as_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'as_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'as_ach', name:'ACH Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'as_cash_usd', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  AT: { countryCode:'AT', countryName:'Austria', defaultCurrency:'EUR', paymentMethods:[
    {id:'at_erste', name:'Erste Bank', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'at_eps', name:'EPS (Electronic Payment Standard)', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'at_paydirekt', name:'Paydirekt', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'at_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'at_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true}
  ]},
  AU: { countryCode:'AU', countryName:'Australia', defaultCurrency:'AUD', paymentMethods:[
    {id:'au_cba', name:'Commonwealth Bank', type:'bank', supportedCurrencies:['AUD'], isActive:true},
    {id:'au_payid', name:'PayID / Osko', type:'local_transfer', supportedCurrencies:['AUD'], isActive:true},
    {id:'au_afterpay', name:'Afterpay / Zip', type:'digital_wallet', supportedCurrencies:['AUD'], isActive:true},
    {id:'au_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AUD'], isActive:true},
    {id:'au_bpay', name:'BPAY', type:'local_transfer', supportedCurrencies:['AUD'], isActive:true}
  ]},
  AW: { countryCode:'AW', countryName:'Aruba', defaultCurrency:'AWG', paymentMethods:[
    {id:'aw_rbc', name:'RBC Royal Bank', type:'bank', supportedCurrencies:['AWG','USD'], isActive:true},
    {id:'aw_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AWG','USD'], isActive:true},
    {id:'aw_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'aw_wire', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['AWG'], isActive:true},
    {id:'aw_cash', name:'Cash (AWG/USD)', type:'cash', supportedCurrencies:['AWG','USD'], isActive:true}
  ]},
  AX: { countryCode:'AX', countryName:'Åland Islands', defaultCurrency:'EUR', paymentMethods:[
    {id:'ax_op', name:'OP Financial Group', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'ax_mobilepay', name:'MobilePay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'ax_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'ax_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'ax_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  AZ: { countryCode:'AZ', countryName:'Azerbaijan', defaultCurrency:'AZN', paymentMethods:[
    {id:'az_kapital', name:'Kapital Bank', type:'bank', supportedCurrencies:['AZN'], isActive:true},
    {id:'az_e_manat', name:'e-Manat', type:'digital_wallet', supportedCurrencies:['AZN'], isActive:true},
    {id:'az_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AZN'], isActive:true},
    {id:'az_central', name:'Central Bank Transfer', type:'local_transfer', supportedCurrencies:['AZN'], isActive:true},
    {id:'az_cash', name:'Cash (AZN)', type:'cash', supportedCurrencies:['AZN'], isActive:true}
  ]},
  BA: { countryCode:'BA', countryName:'Bosnia & Herzegovina', defaultCurrency:'BAM', paymentMethods:[
    {id:'ba_uni_credit', name:'UniCredit Bank', type:'bank', supportedCurrencies:['BAM'], isActive:true},
    {id:'ba_monri', name:'Monri Pay', type:'digital_wallet', supportedCurrencies:['BAM','EUR'], isActive:true},
    {id:'ba_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BAM','EUR'], isActive:true},
    {id:'ba_upn', name:'UPN Transfer', type:'local_transfer', supportedCurrencies:['BAM'], isActive:true},
    {id:'ba_cash', name:'Cash (BAM)', type:'cash', supportedCurrencies:['BAM'], isActive:true}
  ]},
  BB: { countryCode:'BB', countryName:'Barbados', defaultCurrency:'BBD', paymentMethods:[
    {id:'bb_cibc', name:'CIBC FirstCaribbean', type:'bank', supportedCurrencies:['BBD'], isActive:true},
    {id:'bb_bmobile_cash', name:'Digicel Bmobile Cash', type:'digital_wallet', supportedCurrencies:['BBD'], isActive:true},
    {id:'bb_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BBD','USD'], isActive:true},
    {id:'bb_wir', name:'WIR/Local Bank Transfer', type:'local_transfer', supportedCurrencies:['BBD'], isActive:true},
    {id:'bb_cash', name:'Cash (BBD)', type:'cash', supportedCurrencies:['BBD'], isActive:true}
  ]},
  BD: { countryCode:'BD', countryName:'Bangladesh', defaultCurrency:'BDT', paymentMethods:[
    {id:'bd_dbbl', name:'Dutch-Bangla Bank', type:'bank', supportedCurrencies:['BDT'], isActive:true},
    {id:'bd_bkash', name:'bKash', type:'digital_wallet', supportedCurrencies:['BDT'], isActive:true},
    {id:'bd_nagad', name:'Nagad', type:'digital_wallet', supportedCurrencies:['BDT'], isActive:true},
    {id:'bd_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BDT'], isActive:true},
    {id:'bd_beftn', name:'BEFTN Transfer', type:'local_transfer', supportedCurrencies:['BDT'], isActive:true}
  ]},
  BE: { countryCode:'BE', countryName:'Belgium', defaultCurrency:'EUR', paymentMethods:[
    {id:'be_belfius', name:'Belfius', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'be_bancontact', name:'Bancontact / Payconiq', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'be_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'be_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'be_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  BF: { countryCode:'BF', countryName:'Burkina Faso', defaultCurrency:'XOF', paymentMethods:[
    {id:'bf_ecobank', name:'Ecobank', type:'bank', supportedCurrencies:['XOF'], isActive:true},
    {id:'bf_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'bf_moov_money', name:'Moov Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'bf_visa', name:'Visa', type:'card', supportedCurrencies:['XOF','EUR'], isActive:true},
    {id:'bf_om_transfer', name:'Mobile Transfer (WAEMU)', type:'local_transfer', supportedCurrencies:['XOF'], isActive:true}
  ]},
  BG: { countryCode:'BG', countryName:'Bulgaria', defaultCurrency:'BGN', paymentMethods:[
    {id:'bg_dsk', name:'DSK Bank', type:'bank', supportedCurrencies:['BGN'], isActive:true},
    {id:'bg_bpay', name:'B-Pay', type:'digital_wallet', supportedCurrencies:['BGN'], isActive:true},
    {id:'bg_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BGN','EUR'], isActive:true},
    {id:'bg_easy_pay', name:'EasyPay', type:'local_transfer', supportedCurrencies:['BGN'], isActive:true},
    {id:'bg_cash', name:'Cash (BGN)', type:'cash', supportedCurrencies:['BGN'], isActive:true}
  ]},
  BH: { countryCode:'BH', countryName:'Bahrain', defaultCurrency:'BHD', paymentMethods:[
    {id:'bh_nbb', name:'National Bank of Bahrain', type:'bank', supportedCurrencies:['BHD'], isActive:true},
    {id:'bh_benefit', name:'Benefit Pay', type:'digital_wallet', supportedCurrencies:['BHD'], isActive:true},
    {id:'bh_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BHD'], isActive:true},
    {id:'bh_fawri', name:'Fawri+ Instant Transfer', type:'local_transfer', supportedCurrencies:['BHD'], isActive:true},
    {id:'bh_cash', name:'Cash (BHD)', type:'cash', supportedCurrencies:['BHD'], isActive:true}
  ]},
  BI: { countryCode:'BI', countryName:'Burundi', defaultCurrency:'BIF', paymentMethods:[
    {id:'bi_banco', name:'Bank of Africa Burundi', type:'bank', supportedCurrencies:['BIF'], isActive:true},
    {id:'bi_lumicash', name:'Lumicash', type:'digital_wallet', supportedCurrencies:['BIF'], isActive:true},
    {id:'bi_econet', name:'EcoCash', type:'digital_wallet', supportedCurrencies:['BIF'], isActive:true},
    {id:'bi_visa', name:'Visa', type:'card', supportedCurrencies:['USD','BIF'], isActive:true},
    {id:'bi_cash', name:'Cash (BIF)', type:'cash', supportedCurrencies:['BIF'], isActive:true}
  ]},
  BJ: { countryCode:'BJ', countryName:'Benin', defaultCurrency:'XOF', paymentMethods:[
    {id:'bj_coris', name:'Coris Bank', type:'bank', supportedCurrencies:['XOF'], isActive:true},
    {id:'bj_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'bj_moov_money', name:'Moov Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'bj_visa', name:'Visa', type:'card', supportedCurrencies:['XOF','EUR'], isActive:true},
    {id:'bj_transfer', name:'WAEMU Transfer', type:'local_transfer', supportedCurrencies:['XOF'], isActive:true}
  ]},
  BL: { countryCode:'BL', countryName:'Saint Barthélemy', defaultCurrency:'EUR', paymentMethods:[
    {id:'bl_credit_agricole', name:'Crédit Agricole', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'bl_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'bl_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'bl_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'bl_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  BM: { countryCode:'BM', countryName:'Bermuda', defaultCurrency:'BMD', paymentMethods:[
    {id:'bm_hsbc_bm', name:'HSBC Bermuda', type:'bank', supportedCurrencies:['BMD','USD'], isActive:true},
    {id:'bm_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BMD','USD'], isActive:true},
    {id:'bm_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'bm_wire', name:'Local Bank Wire', type:'local_transfer', supportedCurrencies:['BMD'], isActive:true},
    {id:'bm_cash', name:'Cash (BMD/USD)', type:'cash', supportedCurrencies:['BMD','USD'], isActive:true}
  ]},
  BN: { countryCode:'BN', countryName:'Brunei', defaultCurrency:'BND', paymentMethods:[
    {id:'bn_bibd', name:'BIBD', type:'bank', supportedCurrencies:['BND'], isActive:true},
    {id:'bn_bnext', name:'B-Next / B-Digital', type:'digital_wallet', supportedCurrencies:['BND'], isActive:true},
    {id:'bn_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BND'], isActive:true},
    {id:'bn_duitnow', name:'DuitNow QR / Transfer', type:'local_transfer', supportedCurrencies:['BND','MYR'], isActive:true},
    {id:'bn_cash', name:'Cash (BND)', type:'cash', supportedCurrencies:['BND'], isActive:true}
  ]},
  BO: { countryCode:'BO', countryName:'Bolivia', defaultCurrency:'BOB', paymentMethods:[
    {id:'bo_bnb', name:'Banco Nacional de Bolivia', type:'bank', supportedCurrencies:['BOB'], isActive:true},
    {id:'bo_tigo_money', name:'Tigo Money', type:'digital_wallet', supportedCurrencies:['BOB'], isActive:true},
    {id:'bo_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BOB'], isActive:true},
    {id:'bo_sitrans', name:'Sitrans / Bank Transfer', type:'local_transfer', supportedCurrencies:['BOB'], isActive:true},
    {id:'bo_cash', name:'Cash (BOB)', type:'cash', supportedCurrencies:['BOB'], isActive:true}
  ]},
  BQ: { countryCode:'BQ', countryName:'Caribbean Netherlands', defaultCurrency:'USD', paymentMethods:[
    {id:'bq_rbc', name:'RBC Bank', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'bq_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'bq_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'bq_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'bq_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  BR: { countryCode:'BR', countryName:'Brazil', defaultCurrency:'BRL', paymentMethods:[
    {id:'br_itau', name:'Itaú', type:'bank', supportedCurrencies:['BRL'], isActive:true},
    {id:'br_nubank', name:'Nubank', type:'digital_wallet', supportedCurrencies:['BRL'], isActive:true},
    {id:'br_pix', name:'PIX', type:'local_transfer', supportedCurrencies:['BRL'], isActive:true},
    {id:'br_boleto', name:'Boleto Bancário', type:'cash', supportedCurrencies:['BRL'], isActive:true},
    {id:'br_mercadopago', name:'Mercado Pago', type:'digital_wallet', supportedCurrencies:['BRL'], isActive:true}
  ]},
  BS: { countryCode:'BS', countryName:'Bahamas', defaultCurrency:'BSD', paymentMethods:[
    {id:'bs_rbc', name:'RBC Royal Bank', type:'bank', supportedCurrencies:['BSD','USD'], isActive:true},
    {id:'bs_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BSD','USD'], isActive:true},
    {id:'bs_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'bs_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['BSD'], isActive:true},
    {id:'bs_cash', name:'Cash (BSD/USD)', type:'cash', supportedCurrencies:['BSD','USD'], isActive:true}
  ]},
  BT: { countryCode:'BT', countryName:'Bhutan', defaultCurrency:'BTN', paymentMethods:[
    {id:'bt_bnb', name:'Bank of Bhutan', type:'bank', supportedCurrencies:['BTN'], isActive:true},
    {id:'bt_mpay', name:'mPay', type:'digital_wallet', supportedCurrencies:['BTN'], isActive:true},
    {id:'bt_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BTN','INR'], isActive:true},
    {id:'bt_bft', name:'Bhutan Fast Transfer', type:'local_transfer', supportedCurrencies:['BTN'], isActive:true},
    {id:'bt_cash', name:'Cash (BTN/INR)', type:'cash', supportedCurrencies:['BTN','INR'], isActive:true}
  ]},
  BV: { countryCode:'BV', countryName:'Bouvet Island', defaultCurrency:'NOK', paymentMethods:[
    {id:'bv_nordea', name:'Nordea Bank', type:'bank', supportedCurrencies:['NOK'], isActive:true},
    {id:'bv_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['NOK'], isActive:true},
    {id:'bv_vipps', name:'Vipps', type:'digital_wallet', supportedCurrencies:['NOK'], isActive:true},
    {id:'bv_bank_transfer', name:'Bank Transfer', type:'local_transfer', supportedCurrencies:['NOK'], isActive:true},
    {id:'bv_cash', name:'Cash (NOK)', type:'cash', supportedCurrencies:['NOK'], isActive:true}
  ]},
  BW: { countryCode:'BW', countryName:'Botswana', defaultCurrency:'BWP', paymentMethods:[
    {id:'bw_fnb', name:'First National Bank', type:'bank', supportedCurrencies:['BWP'], isActive:true},
    {id:'bw_my_zain', name:'My Zain / Mascom Money', type:'digital_wallet', supportedCurrencies:['BWP'], isActive:true},
    {id:'bw_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BWP'], isActive:true},
    {id:'bw_eft', name:'EFT Transfer', type:'local_transfer', supportedCurrencies:['BWP'], isActive:true},
    {id:'bw_cash', name:'Cash (BWP)', type:'cash', supportedCurrencies:['BWP'], isActive:true}
  ]},
  BY: { countryCode:'BY', countryName:'Belarus', defaultCurrency:'BYN', paymentMethods:[
    {id:'by_belarusbank', name:'Belarusbank', type:'bank', supportedCurrencies:['BYN'], isActive:true},
    {id:'by_erip', name:'ERIP', type:'local_transfer', supportedCurrencies:['BYN'], isActive:true},
    {id:'by_beeline_pay', name:'Beeline Pay', type:'digital_wallet', supportedCurrencies:['BYN'], isActive:true},
    {id:'by_belkart', name:'Belkart', type:'card', supportedCurrencies:['BYN'], isActive:true},
    {id:'by_cash', name:'Cash (BYN)', type:'cash', supportedCurrencies:['BYN'], isActive:true}
  ]},
  BZ: { countryCode:'BZ', countryName:'Belize', defaultCurrency:'BZD', paymentMethods:[
    {id:'bz_belize_bank', name:'Belize Bank', type:'bank', supportedCurrencies:['BZD','USD'], isActive:true},
    {id:'bz_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['BZD','USD'], isActive:true},
    {id:'bz_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'bz_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['BZD'], isActive:true},
    {id:'bz_cash', name:'Cash (BZD/USD)', type:'cash', supportedCurrencies:['BZD','USD'], isActive:true}
  ]},
  CA: { countryCode:'CA', countryName:'Canada', defaultCurrency:'CAD', paymentMethods:[
    {id:'ca_td', name:'TD Canada Trust', type:'bank', supportedCurrencies:['CAD'], isActive:true},
    {id:'ca_interac', name:'Interac e-Transfer', type:'local_transfer', supportedCurrencies:['CAD'], isActive:true},
    {id:'ca_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['CAD'], isActive:true},
    {id:'ca_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['CAD'], isActive:true},
    {id:'ca_lynk', name:'Lynk / Wealthsimple', type:'digital_wallet', supportedCurrencies:['CAD'], isActive:true}
  ]},
  CC: { countryCode:'CC', countryName:'Cocos Islands', defaultCurrency:'AUD', paymentMethods:[
    {id:'cc_cba', name:'Commonwealth Bank', type:'bank', supportedCurrencies:['AUD'], isActive:true},
    {id:'cc_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AUD'], isActive:true},
    {id:'cc_payid', name:'PayID / Osko', type:'local_transfer', supportedCurrencies:['AUD'], isActive:true},
    {id:'cc_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['AUD'], isActive:true},
    {id:'cc_cash', name:'Cash (AUD)', type:'cash', supportedCurrencies:['AUD'], isActive:true}
  ]},
  CD: { countryCode:'CD', countryName:'DR Congo', defaultCurrency:'CDF', paymentMethods:[
    {id:'cd_equity', name:'Equity BCDC', type:'bank', supportedCurrencies:['CDF','USD'], isActive:true},
    {id:'cd_afrimoney', name:'Africell Money / Vodacash', type:'digital_wallet', supportedCurrencies:['CDF'], isActive:true},
    {id:'cd_visa', name:'Visa', type:'card', supportedCurrencies:['USD','CDF'], isActive:true},
    {id:'cd_transfer', name:'Mobile Money Transfer', type:'local_transfer', supportedCurrencies:['CDF'], isActive:true},
    {id:'cd_cash', name:'Cash (CDF/USD)', type:'cash', supportedCurrencies:['CDF','USD'], isActive:true}
  ]},
  CF: { countryCode:'CF', countryName:'Central African Republic', defaultCurrency:'XAF', paymentMethods:[
    {id:'cf_bec', name:'BEAC / Commercial Banks', type:'bank', supportedCurrencies:['XAF'], isActive:true},
    {id:'cf_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'cf_moov_money', name:'Moov Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'cf_visa', name:'Visa', type:'card', supportedCurrencies:['XAF','EUR'], isActive:true},
    {id:'cf_cash', name:'Cash (XAF)', type:'cash', supportedCurrencies:['XAF'], isActive:true}
  ]},
  CG: { countryCode:'CG', countryName:'Republic of Congo', defaultCurrency:'XAF', paymentMethods:[
    {id:'cg_bcdc', name:'BGFI Bank', type:'bank', supportedCurrencies:['XAF'], isActive:true},
    {id:'cg_airtel_money', name:'Airtel Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'cg_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'cg_visa', name:'Visa', type:'card', supportedCurrencies:['XAF','EUR'], isActive:true},
    {id:'cg_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['XAF'], isActive:true}
  ]},
  CH: { countryCode:'CH', countryName:'Switzerland', defaultCurrency:'CHF', paymentMethods:[
    {id:'ch_ubs', name:'UBS', type:'bank', supportedCurrencies:['CHF'], isActive:true},
    {id:'ch_twint', name:'TWINT', type:'digital_wallet', supportedCurrencies:['CHF'], isActive:true},
    {id:'ch_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['CHF'], isActive:true},
    {id:'ch_sic', name:'SIC / PostFinance Transfer', type:'local_transfer', supportedCurrencies:['CHF'], isActive:true},
    {id:'ch_cash', name:'Cash (CHF)', type:'cash', supportedCurrencies:['CHF'], isActive:true}
  ]},
  CI: { countryCode:'CI', countryName:'Ivory Coast', defaultCurrency:'XOF', paymentMethods:[
    {id:'ci_ecobank', name:'Ecobank', type:'bank', supportedCurrencies:['XOF'], isActive:true},
    {id:'ci_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'ci_moov_money', name:'Moov Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'ci_visa', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XOF','EUR'], isActive:true},
    {id:'ci_transfer', name:'WAEMU Transfer', type:'local_transfer', supportedCurrencies:['XOF'], isActive:true}
  ]},
  CK: { countryCode:'CK', countryName:'Cook Islands', defaultCurrency:'NZD', paymentMethods:[
    {id:'ck_anz', name:'ANZ Bank', type:'bank', supportedCurrencies:['NZD'], isActive:true},
    {id:'ck_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['NZD'], isActive:true},
    {id:'ck_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['NZD','USD'], isActive:true},
    {id:'ck_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['NZD'], isActive:true},
    {id:'ck_cash', name:'Cash (NZD)', type:'cash', supportedCurrencies:['NZD'], isActive:true}
  ]},
  CL: { countryCode:'CL', countryName:'Chile', defaultCurrency:'CLP', paymentMethods:[
    {id:'cl_santander', name:'Banco Santander', type:'bank', supportedCurrencies:['CLP'], isActive:true},
    {id:'cl_webpay', name:'Webpay / Transbank', type:'local_transfer', supportedCurrencies:['CLP'], isActive:true},
    {id:'cl_mercadopago', name:'Mercado Pago', type:'digital_wallet', supportedCurrencies:['CLP'], isActive:true},
    {id:'cl_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['CLP'], isActive:true},
    {id:'cl_redcompra', name:'Redcompra (Debit)', type:'card', supportedCurrencies:['CLP'], isActive:true}
  ]},
  CM: { countryCode:'CM', countryName:'Cameroon', defaultCurrency:'XAF', paymentMethods:[
    {id:'cm_ecobank', name:'Ecobank', type:'bank', supportedCurrencies:['XAF'], isActive:true},
    {id:'cm_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'cm_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'cm_visa', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XAF','EUR'], isActive:true},
    {id:'cm_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['XAF'], isActive:true}
  ]},
  CN: { countryCode:'CN', countryName:'China', defaultCurrency:'CNY', paymentMethods:[
    {id:'cn_alipay', name:'Alipay', type:'digital_wallet', supportedCurrencies:['CNY'], isActive:true},
    {id:'cn_wechat', name:'WeChat Pay', type:'digital_wallet', supportedCurrencies:['CNY'], isActive:true},
    {id:'cn_unionpay', name:'UnionPay', type:'card', supportedCurrencies:['CNY'], isActive:true},
    {id:'cn_icbc', name:'ICBC', type:'bank', supportedCurrencies:['CNY'], isActive:true},
    {id:'cn_boa_cn', name:'Bank of China', type:'bank', supportedCurrencies:['CNY'], isActive:true}
  ]},
  CO: { countryCode:'CO', countryName:'Colombia', defaultCurrency:'COP', paymentMethods:[
    {id:'co_bancolombia', name:'Bancolombia', type:'bank', supportedCurrencies:['COP'], isActive:true},
    {id:'co_nequi', name:'Nequi', type:'digital_wallet', supportedCurrencies:['COP'], isActive:true},
    {id:'co_pse', name:'PSE', type:'local_transfer', supportedCurrencies:['COP'], isActive:true},
    {id:'co_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['COP'], isActive:true},
    {id:'co_efecty', name:'Efecty / Baloto', type:'cash', supportedCurrencies:['COP'], isActive:true}
  ]},
  CR: { countryCode:'CR', countryName:'Costa Rica', defaultCurrency:'CRC', paymentMethods:[
    {id:'cr_bncr', name:'Banco Nacional', type:'bank', supportedCurrencies:['CRC'], isActive:true},
    {id:'cr_sinpe', name:'SINPE Móvil', type:'local_transfer', supportedCurrencies:['CRC'], isActive:true},
    {id:'cr_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['CRC'], isActive:true},
    {id:'cr_peel', name:'Peel / Tigo Money', type:'digital_wallet', supportedCurrencies:['CRC'], isActive:true},
    {id:'cr_cash', name:'Cash (CRC/USD)', type:'cash', supportedCurrencies:['CRC','USD'], isActive:true}
  ]},
  CU: { countryCode:'CU', countryName:'Cuba', defaultCurrency:'CUP', paymentMethods:[
    {id:'cu_bpa', name:'Banco Popular de Ahorro', type:'bank', supportedCurrencies:['CUP'], isActive:true},
    {id:'cu_enzona', name:'EnZona', type:'digital_wallet', supportedCurrencies:['CUP'], isActive:true},
    {id:'cu_transfermovil', name:'Transfermóvil', type:'digital_wallet', supportedCurrencies:['CUP'], isActive:true},
    {id:'cu_visa', name:'Visa/Mastercard (Foreign)', type:'card', supportedCurrencies:['USD','EUR'], isActive:true},
    {id:'cu_cash', name:'Cash (CUP/USD)', type:'cash', supportedCurrencies:['CUP','USD'], isActive:true}
  ]},
  CV: { countryCode:'CV', countryName:'Cape Verde', defaultCurrency:'CVE', paymentMethods:[
    {id:'cv_bcv', name:'Banco de Cabo Verde', type:'bank', supportedCurrencies:['CVE'], isActive:true},
    {id:'cv_movicel', name:'Movicel / Unitel Money', type:'digital_wallet', supportedCurrencies:['CVE'], isActive:true},
    {id:'cv_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['CVE','EUR'], isActive:true},
    {id:'cv_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['CVE'], isActive:true},
    {id:'cv_cash', name:'Cash (CVE)', type:'cash', supportedCurrencies:['CVE'], isActive:true}
  ]},
  CW: { countryCode:'CW', countryName:'Curaçao', defaultCurrency:'ANG', paymentMethods:[
    {id:'cw_mcb', name:'MCB Bank', type:'bank', supportedCurrencies:['ANG','USD'], isActive:true},
    {id:'cw_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['ANG','USD'], isActive:true},
    {id:'cw_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'cw_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['ANG'], isActive:true},
    {id:'cw_cash', name:'Cash (ANG/USD)', type:'cash', supportedCurrencies:['ANG','USD'], isActive:true}
  ]},
  CX: { countryCode:'CX', countryName:'Christmas Island', defaultCurrency:'AUD', paymentMethods:[
    {id:'cx_cba', name:'Commonwealth Bank', type:'bank', supportedCurrencies:['AUD'], isActive:true},
    {id:'cx_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AUD'], isActive:true},
    {id:'cx_payid', name:'PayID / Osko', type:'local_transfer', supportedCurrencies:['AUD'], isActive:true},
    {id:'cx_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['AUD'], isActive:true},
    {id:'cx_cash', name:'Cash (AUD)', type:'cash', supportedCurrencies:['AUD'], isActive:true}
  ]},
  CY: { countryCode:'CY', countryName:'Cyprus', defaultCurrency:'EUR', paymentMethods:[
    {id:'cy_boc', name:'Bank of Cyprus', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'cy_jcc', name:'JCC Smart / Cardlink', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'cy_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'cy_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'cy_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  CZ: { countryCode:'CZ', countryName:'Czechia', defaultCurrency:'CZK', paymentMethods:[
    {id:'cz_csob', name:'ČSOB', type:'bank', supportedCurrencies:['CZK'], isActive:true},
    {id:'cz_gpay', name:'Google Pay / Apple Pay', type:'digital_wallet', supportedCurrencies:['CZK'], isActive:true},
    {id:'cz_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['CZK'], isActive:true},
    {id:'cz_twisto', name:'Twisto / Skip Pay', type:'local_transfer', supportedCurrencies:['CZK'], isActive:true},
    {id:'cz_cash', name:'Cash (CZK)', type:'cash', supportedCurrencies:['CZK'], isActive:true}
  ]},
  DE: { countryCode:'DE', countryName:'Germany', defaultCurrency:'EUR', paymentMethods:[
    {id:'de_deutsche_bank', name:'Deutsche Bank', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'de_sepa', name:'SEPA Direct Debit', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'de_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'de_sofort', name:'Sofort / Klarna', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'de_girocard', name:'Girocard / EC', type:'card', supportedCurrencies:['EUR'], isActive:true}
  ]},
  DJ: { countryCode:'DJ', countryName:'Djibouti', defaultCurrency:'DJF', paymentMethods:[
    {id:'dj_cbd', name:'Banque Centrale', type:'bank', supportedCurrencies:['DJF'], isActive:true},
    {id:'dj_evatis', name:'Evatis / D-Money', type:'digital_wallet', supportedCurrencies:['DJF'], isActive:true},
    {id:'dj_visa', name:'Visa', type:'card', supportedCurrencies:['DJF','USD'], isActive:true},
    {id:'dj_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['DJF'], isActive:true},
    {id:'dj_cash', name:'Cash (DJF/USD)', type:'cash', supportedCurrencies:['DJF','USD'], isActive:true}
  ]},
  DK: { countryCode:'DK', countryName:'Denmark', defaultCurrency:'DKK', paymentMethods:[
    {id:'dk_nordea', name:'Nordea Bank', type:'bank', supportedCurrencies:['DKK'], isActive:true},
    {id:'dk_mobilepay', name:'MobilePay', type:'digital_wallet', supportedCurrencies:['DKK'], isActive:true},
    {id:'dk_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['DKK'], isActive:true},
    {id:'dk_nets', name:'Nets / Dankort', type:'local_transfer', supportedCurrencies:['DKK'], isActive:true},
    {id:'dk_cash', name:'Cash (DKK)', type:'cash', supportedCurrencies:['DKK'], isActive:true}
  ]},
  DM: { countryCode:'DM', countryName:'Dominica', defaultCurrency:'XCD', paymentMethods:[
    {id:'dm_ncb', name:'NCB Bank', type:'bank', supportedCurrencies:['XCD'], isActive:true},
    {id:'dm_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XCD','USD'], isActive:true},
    {id:'dm_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'dm_transfer', name:'ECCU Transfer', type:'local_transfer', supportedCurrencies:['XCD'], isActive:true},
    {id:'dm_cash', name:'Cash (XCD)', type:'cash', supportedCurrencies:['XCD'], isActive:true}
  ]},
  DO: { countryCode:'DO', countryName:'Dominican Republic', defaultCurrency:'DOP', paymentMethods:[
    {id:'do_banreservas', name:'Banreservas', type:'bank', supportedCurrencies:['DOP'], isActive:true},
    {id:'do_azul', name:'Azul / Tigo Money', type:'digital_wallet', supportedCurrencies:['DOP'], isActive:true},
    {id:'do_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['DOP','USD'], isActive:true},
    {id:'do_atm_transfer', name:'ATM/Local Transfer', type:'local_transfer', supportedCurrencies:['DOP'], isActive:true},
    {id:'do_cash', name:'Cash (DOP/USD)', type:'cash', supportedCurrencies:['DOP','USD'], isActive:true}
  ]},
  DZ: { countryCode:'DZ', countryName:'Algeria', defaultCurrency:'DZD', paymentMethods:[
    {id:'dz_cnea', name:'CNEP-Banque', type:'bank', supportedCurrencies:['DZD'], isActive:true},
    {id:'dz_cib', name:'CIB / EDAHABIA', type:'card', supportedCurrencies:['DZD'], isActive:true},
    {id:'dz_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['DZD','EUR'], isActive:true},
    {id:'dz_satim', name:'SATIM Transfer', type:'local_transfer', supportedCurrencies:['DZD'], isActive:true},
    {id:'dz_cash', name:'Cash (DZD)', type:'cash', supportedCurrencies:['DZD'], isActive:true}
  ]},
  EC: { countryCode:'EC', countryName:'Ecuador', defaultCurrency:'USD', paymentMethods:[
    {id:'ec_pichincha', name:'Banco Pichincha', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'ec_deuna', name:'DeUna / Nequi', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'ec_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'ec_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'ec_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  EE: { countryCode:'EE', countryName:'Estonia', defaultCurrency:'EUR', paymentMethods:[
    {id:'ee_swedbank', name:'Swedbank', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'ee_link', name:'Swedbank Link / Pay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'ee_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'ee_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'ee_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  EG: { countryCode:'EG', countryName:'Egypt', defaultCurrency:'EGP', paymentMethods:[
    {id:'eg_nbe', name:'National Bank of Egypt', type:'bank', supportedCurrencies:['EGP'], isActive:true},
    {id:'eg_vodafone_cash', name:'Vodafone Cash', type:'digital_wallet', supportedCurrencies:['EGP'], isActive:true},
    {id:'eg_fawry', name:'Fawry', type:'cash', supportedCurrencies:['EGP'], isActive:true},
    {id:'eg_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EGP','USD'], isActive:true},
    {id:'eg_meeza', name:'Meeza Transfer', type:'local_transfer', supportedCurrencies:['EGP'], isActive:true}
  ]},
  EH: { countryCode:'EH', countryName:'Western Sahara', defaultCurrency:'MAD', paymentMethods:[
    {id:'eh_bcp', name:'Banque Centrale Populaire', type:'bank', supportedCurrencies:['MAD'], isActive:true},
    {id:'eh_cmi', name:'CMI Pay', type:'local_transfer', supportedCurrencies:['MAD'], isActive:true},
    {id:'eh_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MAD','EUR'], isActive:true},
    {id:'eh_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['MAD'], isActive:true},
    {id:'eh_cash', name:'Cash (MAD)', type:'cash', supportedCurrencies:['MAD'], isActive:true}
  ]},
  ER: { countryCode:'ER', countryName:'Eritrea', defaultCurrency:'ERN', paymentMethods:[
    {id:'er_bonr', name:'Bank of Eritrea', type:'bank', supportedCurrencies:['ERN'], isActive:true},
    {id:'er_visa', name:'Visa (Limited)', type:'card', supportedCurrencies:['USD','ERN'], isActive:true},
    {id:'er_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['ERN'], isActive:true},
    {id:'er_mobile', name:'Mobile Banking', type:'digital_wallet', supportedCurrencies:['ERN'], isActive:true},
    {id:'er_cash', name:'Cash (ERN)', type:'cash', supportedCurrencies:['ERN'], isActive:true}
  ]},
  ES: { countryCode:'ES', countryName:'Spain', defaultCurrency:'EUR', paymentMethods:[
    {id:'es_bbva', name:'BBVA', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'es_bizum', name:'Bizum', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'es_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'es_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'es_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  ET: { countryCode:'ET', countryName:'Ethiopia', defaultCurrency:'ETB', paymentMethods:[
    {id:'et_cbe', name:'Commercial Bank of Ethiopia', type:'bank', supportedCurrencies:['ETB'], isActive:true},
    {id:'et_telebirr', name:'Telebirr', type:'digital_wallet', supportedCurrencies:['ETB'], isActive:true},
    {id:'et_amsel', name:'Amole / M-Pesa', type:'digital_wallet', supportedCurrencies:['ETB'], isActive:true},
    {id:'et_visa', name:'Visa', type:'card', supportedCurrencies:['ETB','USD'], isActive:true},
    {id:'et_transfer', name:'CBE Birr Transfer', type:'local_transfer', supportedCurrencies:['ETB'], isActive:true}
  ]},
  FI: { countryCode:'FI', countryName:'Finland', defaultCurrency:'EUR', paymentMethods:[
    {id:'fi_op', name:'OP Financial Group', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'fi_mobilepay', name:'MobilePay / Pivo', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'fi_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'fi_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'fi_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  FJ: { countryCode:'FJ', countryName:'Fiji', defaultCurrency:'FJD', paymentMethods:[
    {id:'fj_anz', name:'ANZ Fiji', type:'bank', supportedCurrencies:['FJD'], isActive:true},
    {id:'fj_vodafone_mpa', name:'Vodafone M-PAiSA', type:'digital_wallet', supportedCurrencies:['FJD'], isActive:true},
    {id:'fj_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['FJD'], isActive:true},
    {id:'fj_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['FJD'], isActive:true},
    {id:'fj_cash', name:'Cash (FJD)', type:'cash', supportedCurrencies:['FJD'], isActive:true}
  ]},
  FK: { countryCode:'FK', countryName:'Falkland Islands', defaultCurrency:'FKP', paymentMethods:[
    {id:'fk_bfi', name:'Bank of Falkland Islands', type:'bank', supportedCurrencies:['FKP','GBP'], isActive:true},
    {id:'fk_visa', name:'Visa', type:'card', supportedCurrencies:['FKP','GBP'], isActive:true},
    {id:'fk_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['GBP','USD'], isActive:true},
    {id:'fk_transfer', name:'Local Transfer', type:'local_transfer', supportedCurrencies:['FKP'], isActive:true},
    {id:'fk_cash', name:'Cash (FKP/GBP)', type:'cash', supportedCurrencies:['FKP','GBP'], isActive:true}
  ]},
  FM: { countryCode:'FM', countryName:'Micronesia', defaultCurrency:'USD', paymentMethods:[
    {id:'fm_bank_hawaii', name:'Bank of Hawaii', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'fm_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'fm_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'fm_ach', name:'ACH Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'fm_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  FO: { countryCode:'FO', countryName:'Faroe Islands', defaultCurrency:'DKK', paymentMethods:[
    {id:'fo_bank_nordik', name:'Bank Nordik', type:'bank', supportedCurrencies:['DKK'], isActive:true},
    {id:'fo_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['DKK'], isActive:true},
    {id:'fo_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR','DKK'], isActive:true},
    {id:'fo_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['DKK'], isActive:true},
    {id:'fo_cash', name:'Cash (DKK)', type:'cash', supportedCurrencies:['DKK'], isActive:true}
  ]},
  FR: { countryCode:'FR', countryName:'France', defaultCurrency:'EUR', paymentMethods:[
    {id:'fr_bnpp', name:'BNP Paribas', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'fr_lydia', name:'Lydia / Paylib', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'fr_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'fr_sepa', name:'SEPA Instant / Virement', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'fr_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  GA: { countryCode:'GA', countryName:'Gabon', defaultCurrency:'XAF', paymentMethods:[
    {id:'ga_bicig', name:'BICIG', type:'bank', supportedCurrencies:['XAF'], isActive:true},
    {id:'ga_airtel_money', name:'Airtel Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'ga_moov_money', name:'Moov Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'ga_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XAF','EUR'], isActive:true},
    {id:'ga_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['XAF'], isActive:true}
  ]},
  GB: { countryCode:'GB', countryName:'United Kingdom', defaultCurrency:'GBP', paymentMethods:[
    {id:'gb_barclays', name:'Barclays', type:'bank', supportedCurrencies:['GBP'], isActive:true},
    {id:'gb_faster_payments', name:'Faster Payments', type:'local_transfer', supportedCurrencies:['GBP'], isActive:true},
    {id:'gb_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['GBP'], isActive:true},
    {id:'gb_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['GBP'], isActive:true},
    {id:'gb_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GBP'], isActive:true}
  ]},
  GD: { countryCode:'GD', countryName:'Grenada', defaultCurrency:'XCD', paymentMethods:[
    {id:'gd_rbtt', name:'RBTT Bank', type:'bank', supportedCurrencies:['XCD'], isActive:true},
    {id:'gd_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XCD','USD'], isActive:true},
    {id:'gd_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'gd_ecs', name:'ECCU Transfer', type:'local_transfer', supportedCurrencies:['XCD'], isActive:true},
    {id:'gd_cash', name:'Cash (XCD)', type:'cash', supportedCurrencies:['XCD'], isActive:true}
  ]},
  GE: { countryCode:'GE', countryName:'Georgia', defaultCurrency:'GEL', paymentMethods:[
    {id:'ge_tbc', name:'TBC Bank', type:'bank', supportedCurrencies:['GEL'], isActive:true},
    {id:'ge_boa', name:'Bank of Georgia', type:'bank', supportedCurrencies:['GEL'], isActive:true},
    {id:'ge_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GEL'], isActive:true},
    {id:'ge_space', name:'Space / TBC Pay', type:'digital_wallet', supportedCurrencies:['GEL'], isActive:true},
    {id:'ge_cash', name:'Cash (GEL)', type:'cash', supportedCurrencies:['GEL'], isActive:true}
  ]},
  GF: { countryCode:'GF', countryName:'French Guiana', defaultCurrency:'EUR', paymentMethods:[
    {id:'gf_credit_agricole', name:'Crédit Agricole', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'gf_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'gf_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'gf_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'gf_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  GG: { countryCode:'GG', countryName:'Guernsey', defaultCurrency:'GBP', paymentMethods:[
    {id:'gg_lloyds', name:'Lloyds Bank CI', type:'bank', supportedCurrencies:['GBP'], isActive:true},
    {id:'gg_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GBP'], isActive:true},
    {id:'gg_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['GBP'], isActive:true},
    {id:'gg_faster', name:'UK Faster Payments', type:'local_transfer', supportedCurrencies:['GBP'], isActive:true},
    {id:'gg_cash', name:'Cash (GBP)', type:'cash', supportedCurrencies:['GBP'], isActive:true}
  ]},
  GH: { countryCode:'GH', countryName:'Ghana', defaultCurrency:'GHS', paymentMethods:[
    {id:'gh_ecobank', name:'Ecobank', type:'bank', supportedCurrencies:['GHS'], isActive:true},
    {id:'gh_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['GHS'], isActive:true},
    {id:'gh_telecel_cash', name:'Telecel Cash / AirtelTigo', type:'digital_wallet', supportedCurrencies:['GHS'], isActive:true},
    {id:'gh_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GHS'], isActive:true},
    {id:'gh_ghipss', name:'GhIPSS Instant Pay', type:'local_transfer', supportedCurrencies:['GHS'], isActive:true}
  ]},
  GI: { countryCode:'GI', countryName:'Gibraltar', defaultCurrency:'GIP', paymentMethods:[
    {id:'gi_barclays', name:'Barclays Gibraltar', type:'bank', supportedCurrencies:['GIP','GBP'], isActive:true},
    {id:'gi_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GIP','GBP'], isActive:true},
    {id:'gi_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['GBP','USD'], isActive:true},
    {id:'gi_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['GIP'], isActive:true},
    {id:'gi_cash', name:'Cash (GIP/GBP)', type:'cash', supportedCurrencies:['GIP','GBP'], isActive:true}
  ]},
  GL: { countryCode:'GL', countryName:'Greenland', defaultCurrency:'DKK', paymentMethods:[
    {id:'gl_nunaoil', name:'Bank of Greenland', type:'bank', supportedCurrencies:['DKK'], isActive:true},
    {id:'gl_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['DKK'], isActive:true},
    {id:'gl_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['DKK','EUR'], isActive:true},
    {id:'gl_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['DKK'], isActive:true},
    {id:'gl_cash', name:'Cash (DKK)', type:'cash', supportedCurrencies:['DKK'], isActive:true}
  ]},
  GM: { countryCode:'GM', countryName:'Gambia', defaultCurrency:'GMD', paymentMethods:[
    {id:'gm_gcb', name:'GCB Bank', type:'bank', supportedCurrencies:['GMD'], isActive:true},
    {id:'gm_africell', name:'Africell Money', type:'digital_wallet', supportedCurrencies:['GMD'], isActive:true},
    {id:'gm_qmoney', name:'QMoney', type:'digital_wallet', supportedCurrencies:['GMD'], isActive:true},
    {id:'gm_visa', name:'Visa', type:'card', supportedCurrencies:['GMD','USD'], isActive:true},
    {id:'gm_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['GMD'], isActive:true}
  ]},
  GN: { countryCode:'GN', countryName:'Guinea', defaultCurrency:'GNF', paymentMethods:[
    {id:'gn_bceao', name:'BCRG / Local Banks', type:'bank', supportedCurrencies:['GNF'], isActive:true},
    {id:'gn_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['GNF'], isActive:true},
    {id:'gn_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['GNF'], isActive:true},
    {id:'gn_visa', name:'Visa', type:'card', supportedCurrencies:['GNF','USD'], isActive:true},
    {id:'gn_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['GNF'], isActive:true}
  ]},
  GP: { countryCode:'GP', countryName:'Guadeloupe', defaultCurrency:'EUR', paymentMethods:[
    {id:'gp_credit_agricole', name:'Crédit Agricole', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'gp_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'gp_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'gp_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'gp_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  GQ: { countryCode:'GQ', countryName:'Equatorial Guinea', defaultCurrency:'XAF', paymentMethods:[
    {id:'gq_bceae', name:'BCEAE', type:'bank', supportedCurrencies:['XAF'], isActive:true},
    {id:'gq_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'gq_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XAF','EUR'], isActive:true},
    {id:'gq_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['XAF'], isActive:true},
    {id:'gq_cash', name:'Cash (XAF)', type:'cash', supportedCurrencies:['XAF'], isActive:true}
  ]},
  GR: { countryCode:'GR', countryName:'Greece', defaultCurrency:'EUR', paymentMethods:[
    {id:'gr_nbg', name:'National Bank of Greece', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'gr_viva', name:'Viva Wallet / IRIS', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'gr_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'gr_dias', name:'DIAS / IRIS Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'gr_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  GS: { countryCode:'GS', countryName:'South Georgia', defaultCurrency:'GBP', paymentMethods:[
    {id:'gs_lloyds', name:'Lloyds / UK Banks', type:'bank', supportedCurrencies:['GBP'], isActive:true},
    {id:'gs_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GBP'], isActive:true},
    {id:'gs_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['GBP'], isActive:true},
    {id:'gs_faster', name:'UK Faster Payments', type:'local_transfer', supportedCurrencies:['GBP'], isActive:true},
    {id:'gs_cash', name:'Cash (GBP)', type:'cash', supportedCurrencies:['GBP'], isActive:true}
  ]},
  GT: { countryCode:'GT', countryName:'Guatemala', defaultCurrency:'GTQ', paymentMethods:[
    {id:'gt_banco_industrial', name:'Banco Industrial', type:'bank', supportedCurrencies:['GTQ'], isActive:true},
    {id:'gt_tigo_money', name:'Tigo Money', type:'digital_wallet', supportedCurrencies:['GTQ'], isActive:true},
    {id:'gt_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GTQ','USD'], isActive:true},
    {id:'gt_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['GTQ'], isActive:true},
    {id:'gt_cash', name:'Cash (GTQ/USD)', type:'cash', supportedCurrencies:['GTQ','USD'], isActive:true}
  ]},
  GU: { countryCode:'GU', countryName:'Guam', defaultCurrency:'USD', paymentMethods:[
    {id:'gu_bank_hawaii', name:'Bank of Hawaii', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'gu_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'gu_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'gu_ach', name:'ACH Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'gu_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  GW: { countryCode:'GW', countryName:'Guinea-Bissau', defaultCurrency:'XOF', paymentMethods:[
    {id:'gw_bceao', name:'BCEAO', type:'bank', supportedCurrencies:['XOF'], isActive:true},
    {id:'gw_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'gw_visa', name:'Visa', type:'card', supportedCurrencies:['XOF','EUR'], isActive:true},
    {id:'gw_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['XOF'], isActive:true},
    {id:'gw_cash', name:'Cash (XOF)', type:'cash', supportedCurrencies:['XOF'], isActive:true}
  ]},
  GY: { countryCode:'GY', countryName:'Guyana', defaultCurrency:'GYD', paymentMethods:[
    {id:'gy_gbt', name:'GBTI', type:'bank', supportedCurrencies:['GYD','USD'], isActive:true},
    {id:'gy_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GYD','USD'], isActive:true},
    {id:'gy_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'gy_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['GYD'], isActive:true},
    {id:'gy_cash', name:'Cash (GYD/USD)', type:'cash', supportedCurrencies:['GYD','USD'], isActive:true}
  ]},
  HK: { countryCode:'HK', countryName:'Hong Kong', defaultCurrency:'HKD', paymentMethods:[
    {id:'hk_hsbc', name:'HSBC HK', type:'bank', supportedCurrencies:['HKD'], isActive:true},
    {id:'hk_octopus', name:'Octopus Card', type:'card', supportedCurrencies:['HKD'], isActive:true},
    {id:'hk_alipay', name:'AlipayHK', type:'digital_wallet', supportedCurrencies:['HKD'], isActive:true},
    {id:'hk_fps', name:'FPS (Faster Payment System)', type:'local_transfer', supportedCurrencies:['HKD'], isActive:true},
    {id:'hk_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['HKD'], isActive:true}
  ]},
  HM: { countryCode:'HM', countryName:'Heard Island', defaultCurrency:'AUD', paymentMethods:[
    {id:'hm_cba', name:'Commonwealth Bank', type:'bank', supportedCurrencies:['AUD'], isActive:true},
    {id:'hm_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AUD'], isActive:true},
    {id:'hm_payid', name:'PayID / Osko', type:'local_transfer', supportedCurrencies:['AUD'], isActive:true},
    {id:'hm_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['AUD'], isActive:true},
    {id:'hm_cash', name:'Cash (AUD)', type:'cash', supportedCurrencies:['AUD'], isActive:true}
  ]},
  HN: { countryCode:'HN', countryName:'Honduras', defaultCurrency:'HNL', paymentMethods:[
    {id:'hn_ficohsa', name:'Banco Ficohsa', type:'bank', supportedCurrencies:['HNL'], isActive:true},
    {id:'hn_tigo_money', name:'Tigo Money', type:'digital_wallet', supportedCurrencies:['HNL'], isActive:true},
    {id:'hn_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['HNL','USD'], isActive:true},
    {id:'hn_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['HNL'], isActive:true},
    {id:'hn_cash', name:'Cash (HNL/USD)', type:'cash', supportedCurrencies:['HNL','USD'], isActive:true}
  ]},
  HR: { countryCode:'HR', countryName:'Croatia', defaultCurrency:'EUR', paymentMethods:[
    {id:'hr_zaba', name:'Zagrebačka banka', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'hr_banka_pay', name:'Banka Pay / mPay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'hr_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'hr_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'hr_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  HT: { countryCode:'HT', countryName:'Haiti', defaultCurrency:'HTG', paymentMethods:[
    {id:'ht_bnh', name:'Banque Nationale d\'Haïti', type:'bank', supportedCurrencies:['HTG','USD'], isActive:true},
    {id:'ht_natcash', name:'NatCash / MonCash', type:'digital_wallet', supportedCurrencies:['HTG'], isActive:true},
    {id:'ht_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD','HTG'], isActive:true},
    {id:'ht_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['HTG'], isActive:true},
    {id:'ht_cash', name:'Cash (HTG/USD)', type:'cash', supportedCurrencies:['HTG','USD'], isActive:true}
  ]},
  HU: { countryCode:'HU', countryName:'Hungary', defaultCurrency:'HUF', paymentMethods:[
    {id:'hu_otp', name:'OTP Bank', type:'bank', supportedCurrencies:['HUF'], isActive:true},
    {id:'hu_barion', name:'Barion / SimplePay', type:'digital_wallet', supportedCurrencies:['HUF'], isActive:true},
    {id:'hu_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['HUF'], isActive:true},
    {id:'hu_atm', name:'ATM Transfer / GIRO', type:'local_transfer', supportedCurrencies:['HUF'], isActive:true},
    {id:'hu_cash', name:'Cash (HUF)', type:'cash', supportedCurrencies:['HUF'], isActive:true}
  ]},
  ID: { countryCode:'ID', countryName:'Indonesia', defaultCurrency:'IDR', paymentMethods:[
    {id:'id_bca', name:'BCA', type:'bank', supportedCurrencies:['IDR'], isActive:true},
    {id:'id_gopay', name:'GoPay', type:'digital_wallet', supportedCurrencies:['IDR'], isActive:true},
    {id:'id_ovo', name:'OVO', type:'digital_wallet', supportedCurrencies:['IDR'], isActive:true},
    {id:'id_qris', name:'QRIS', type:'local_transfer', supportedCurrencies:['IDR'], isActive:true},
    {id:'id_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['IDR'], isActive:true}
  ]},
  IE: { countryCode:'IE', countryName:'Ireland', defaultCurrency:'EUR', paymentMethods:[
    {id:'ie_aib', name:'AIB', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'ie_revolut', name:'Revolut', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'ie_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'ie_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'ie_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  IL: { countryCode:'IL', countryName:'Israel', defaultCurrency:'ILS', paymentMethods:[
    {id:'il_leumi', name:'Bank Leumi', type:'bank', supportedCurrencies:['ILS'], isActive:true},
    {id:'il_bit', name:'Bit', type:'digital_wallet', supportedCurrencies:['ILS'], isActive:true},
    {id:'il_visa_mc', name:'Visa/Mastercard / Isracard', type:'card', supportedCurrencies:['ILS'], isActive:true},
    {id:'il_paybox', name:'PayBox', type:'digital_wallet', supportedCurrencies:['ILS'], isActive:true},
    {id:'il_transfer', name:'Bank Transfer', type:'local_transfer', supportedCurrencies:['ILS'], isActive:true}
  ]},
  IM: { countryCode:'IM', countryName:'Isle of Man', defaultCurrency:'GBP', paymentMethods:[
    {id:'im_rbc', name:'RBC Isle of Man', type:'bank', supportedCurrencies:['GBP'], isActive:true},
    {id:'im_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GBP'], isActive:true},
    {id:'im_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['GBP'], isActive:true},
    {id:'im_faster', name:'UK Faster Payments', type:'local_transfer', supportedCurrencies:['GBP'], isActive:true},
    {id:'im_cash', name:'Cash (GBP)', type:'cash', supportedCurrencies:['GBP'], isActive:true}
  ]},
  IN: { countryCode:'IN', countryName:'India', defaultCurrency:'INR', paymentMethods:[
    {id:'in_sbi', name:'State Bank of India', type:'bank', supportedCurrencies:['INR'], isActive:true},
    {id:'in_hdfc', name:'HDFC Bank', type:'bank', supportedCurrencies:['INR'], isActive:true},
    {id:'in_upi', name:'UPI (GPay, PhonePe, Paytm)', type:'local_transfer', supportedCurrencies:['INR'], isActive:true},
    {id:'in_netbanking', name:'Net Banking', type:'bank', supportedCurrencies:['INR'], isActive:true},
    {id:'in_wallets', name:'Paytm / Mobikwik', type:'digital_wallet', supportedCurrencies:['INR'], isActive:true}
  ]},
  IO: { countryCode:'IO', countryName:'British Indian Ocean Territory', defaultCurrency:'USD', paymentMethods:[
    {id:'io_uk_bank', name:'UK Bank / MOD Pay', type:'bank', supportedCurrencies:['USD','GBP'], isActive:true},
    {id:'io_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'io_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'io_transfer', name:'International Wire', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'io_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  IQ: { countryCode:'IQ', countryName:'Iraq', defaultCurrency:'IQD', paymentMethods:[
    {id:'iq_trade', name:'Trade Bank of Iraq', type:'bank', supportedCurrencies:['IQD'], isActive:true},
    {id:'iq_zain_cash', name:'ZainCash', type:'digital_wallet', supportedCurrencies:['IQD'], isActive:true},
    {id:'iq_asiacell', name:'AsiaCell Pay', type:'digital_wallet', supportedCurrencies:['IQD'], isActive:true},
    {id:'iq_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['IQD','USD'], isActive:true},
    {id:'iq_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['IQD'], isActive:true}
  ]},
  IR: { countryCode:'IR', countryName:'Iran', defaultCurrency:'IRR', paymentMethods:[
    {id:'ir_melli', name:'Bank Melli', type:'bank', supportedCurrencies:['IRR'], isActive:true},
    {id:'ir_shaparak', name:'Shaparak / Shetab', type:'local_transfer', supportedCurrencies:['IRR'], isActive:true},
    {id:'ir_snapp_pay', name:'Snapp! Pay / Digipay', type:'digital_wallet', supportedCurrencies:['IRR'], isActive:true},
    {id:'ir_kart_be_kart', name:'Kart-be-Kart', type:'card', supportedCurrencies:['IRR'], isActive:true},
    {id:'ir_cash', name:'Cash (IRR)', type:'cash', supportedCurrencies:['IRR'], isActive:true}
  ]},
  IS: { countryCode:'IS', countryName:'Iceland', defaultCurrency:'ISK', paymentMethods:[
    {id:'is_landsbankinn', name:'Landsbankinn', type:'bank', supportedCurrencies:['ISK'], isActive:true},
    {id:'is_mobile_pay', name:'MobilePay / Pei', type:'digital_wallet', supportedCurrencies:['ISK'], isActive:true},
    {id:'is_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['ISK'], isActive:true},
    {id:'is_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['ISK','EUR'], isActive:true},
    {id:'is_cash', name:'Cash (ISK)', type:'cash', supportedCurrencies:['ISK'], isActive:true}
  ]},
  IT: { countryCode:'IT', countryName:'Italy', defaultCurrency:'EUR', paymentMethods:[
    {id:'it_intesa', name:'Intesa Sanpaolo', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'it_satispay', name:'Satispay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'it_bancomat_pay', name:'Bancomat Pay', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'it_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'it_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  JE: { countryCode:'JE', countryName:'Jersey', defaultCurrency:'GBP', paymentMethods:[
    {id:'je_hsbc', name:'HSBC Jersey', type:'bank', supportedCurrencies:['GBP'], isActive:true},
    {id:'je_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['GBP'], isActive:true},
    {id:'je_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['GBP'], isActive:true},
    {id:'je_faster', name:'UK Faster Payments', type:'local_transfer', supportedCurrencies:['GBP'], isActive:true},
    {id:'je_cash', name:'Cash (GBP)', type:'cash', supportedCurrencies:['GBP'], isActive:true}
  ]},
  JM: { countryCode:'JM', countryName:'Jamaica', defaultCurrency:'JMD', paymentMethods:[
    {id:'jm_ncb', name:'NCB Jamaica', type:'bank', supportedCurrencies:['JMD'], isActive:true},
    {id:'jm_linx', name:'Linx / Digicel Money', type:'digital_wallet', supportedCurrencies:['JMD'], isActive:true},
    {id:'jm_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['JMD','USD'], isActive:true},
    {id:'jm_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['JMD'], isActive:true},
    {id:'jm_cash', name:'Cash (JMD/USD)', type:'cash', supportedCurrencies:['JMD','USD'], isActive:true}
  ]},
  JO: { countryCode:'JO', countryName:'Jordan', defaultCurrency:'JOD', paymentMethods:[
    {id:'jo_arabi', name:'Arab Bank', type:'bank', supportedCurrencies:['JOD'], isActive:true},
    {id:'jo_cliQ', name:'CliQ', type:'local_transfer', supportedCurrencies:['JOD'], isActive:true},
    {id:'jo_zain_cash', name:'Zain Cash / Orange Money', type:'digital_wallet', supportedCurrencies:['JOD'], isActive:true},
    {id:'jo_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['JOD'], isActive:true},
    {id:'jo_cash', name:'Cash (JOD)', type:'cash', supportedCurrencies:['JOD'], isActive:true}
  ]},
  JP: { countryCode:'JP', countryName:'Japan', defaultCurrency:'JPY', paymentMethods:[
    {id:'jp_mizuho', name:'Mizuho Bank', type:'bank', supportedCurrencies:['JPY'], isActive:true},
    {id:'jp_paypay', name:'PayPay', type:'digital_wallet', supportedCurrencies:['JPY'], isActive:true},
    {id:'jp_line_pay', name:'LINE Pay', type:'digital_wallet', supportedCurrencies:['JPY'], isActive:true},
    {id:'jp_jcb', name:'JCB', type:'card', supportedCurrencies:['JPY'], isActive:true},
    {id:'jp_zengin', name:'Zengin System', type:'local_transfer', supportedCurrencies:['JPY'], isActive:true}
  ]},
  KE: { countryCode:'KE', countryName:'Kenya', defaultCurrency:'KES', paymentMethods:[
    {id:'ke_mpesa', name:'M-Pesa', type:'digital_wallet', supportedCurrencies:['KES'], isActive:true},
    {id:'ke_equity', name:'Equity Bank', type:'bank', supportedCurrencies:['KES'], isActive:true},
    {id:'ke_kcb', name:'KCB Bank', type:'bank', supportedCurrencies:['KES'], isActive:true},
    {id:'ke_airtel_money', name:'Airtel Money', type:'digital_wallet', supportedCurrencies:['KES'], isActive:true},
    {id:'ke_pesa_link', name:'PesaLink / Instant Transfer', type:'local_transfer', supportedCurrencies:['KES'], isActive:true}
  ]},
  KG: { countryCode:'KG', countryName:'Kyrgyzstan', defaultCurrency:'KGS', paymentMethods:[
    {id:'kg_kicb', name:'KICB', type:'bank', supportedCurrencies:['KGS'], isActive:true},
    {id:'kg_elsom', name:'Elsom', type:'digital_wallet', supportedCurrencies:['KGS'], isActive:true},
    {id:'kg_mega_pay', name:'MegaPay / O!', type:'digital_wallet', supportedCurrencies:['KGS'], isActive:true},
    {id:'kg_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['KGS'], isActive:true},
    {id:'kg_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['KGS'], isActive:true}
  ]},
  KH: { countryCode:'KH', countryName:'Cambodia', defaultCurrency:'KHR', paymentMethods:[
    {id:'kh_acleda', name:'ACLEDA Bank', type:'bank', supportedCurrencies:['KHR','USD'], isActive:true},
    {id:'kh_wing', name:'Wing Money', type:'digital_wallet', supportedCurrencies:['KHR','USD'], isActive:true},
    {id:'kh_truemoney', name:'TrueMoney / Pi Pay', type:'digital_wallet', supportedCurrencies:['KHR'], isActive:true},
    {id:'kh_bakong', name:'Bakong', type:'local_transfer', supportedCurrencies:['KHR','USD'], isActive:true},
    {id:'kh_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD','KHR'], isActive:true}
  ]},
  KI: { countryCode:'KI', countryName:'Kiribati', defaultCurrency:'AUD', paymentMethods:[
    {id:'ki_anz', name:'ANZ Bank', type:'bank', supportedCurrencies:['AUD'], isActive:true},
    {id:'ki_visa', name:'Visa', type:'card', supportedCurrencies:['AUD'], isActive:true},
    {id:'ki_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['AUD','USD'], isActive:true},
    {id:'ki_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['AUD'], isActive:true},
    {id:'ki_cash', name:'Cash (AUD)', type:'cash', supportedCurrencies:['AUD'], isActive:true}
  ]},
  KM: { countryCode:'KM', countryName:'Comoros', defaultCurrency:'KMF', paymentMethods:[
    {id:'km_bdc', name:'Banque de Développement des Comores', type:'bank', supportedCurrencies:['KMF'], isActive:true},
    {id:'km_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['KMF'], isActive:true},
    {id:'km_visa', name:'Visa', type:'card', supportedCurrencies:['KMF','EUR'], isActive:true},
    {id:'km_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['KMF'], isActive:true},
    {id:'km_cash', name:'Cash (KMF)', type:'cash', supportedCurrencies:['KMF'], isActive:true}
  ]},
  KN: { countryCode:'KN', countryName:'Saint Kitts & Nevis', defaultCurrency:'XCD', paymentMethods:[
    {id:'kn_scotia', name:'Scotiabank', type:'bank', supportedCurrencies:['XCD'], isActive:true},
    {id:'kn_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XCD','USD'], isActive:true},
    {id:'kn_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'kn_transfer', name:'ECCU Transfer', type:'local_transfer', supportedCurrencies:['XCD'], isActive:true},
    {id:'kn_cash', name:'Cash (XCD)', type:'cash', supportedCurrencies:['XCD'], isActive:true}
  ]},
  KP: { countryCode:'KP', countryName:'North Korea', defaultCurrency:'KPW', paymentMethods:[
    {id:'kp_cbk', name:'Central Bank', type:'bank', supportedCurrencies:['KPW'], isActive:true},
    {id:'kp_visa', name:'Visa (Restricted)', type:'card', supportedCurrencies:['USD','EUR'], isActive:true},
    {id:'kp_transfer', name:'State Transfer', type:'local_transfer', supportedCurrencies:['KPW'], isActive:true},
    {id:'kp_mobile', name:'Koryolink Pay', type:'digital_wallet', supportedCurrencies:['KPW'], isActive:true},
    {id:'kp_cash', name:'Cash (KPW)', type:'cash', supportedCurrencies:['KPW'], isActive:true}
  ]},
  KR: { countryCode:'KR', countryName:'South Korea', defaultCurrency:'KRW', paymentMethods:[
    {id:'kr_shinhan', name:'Shinhan Bank', type:'bank', supportedCurrencies:['KRW'], isActive:true},
    {id:'kr_kakao_pay', name:'KakaoPay', type:'digital_wallet', supportedCurrencies:['KRW'], isActive:true},
    {id:'kr_naver_pay', name:'Naver Pay', type:'digital_wallet', supportedCurrencies:['KRW'], isActive:true},
    {id:'kr_samsung_pay', name:'Samsung Pay / BC Card', type:'card', supportedCurrencies:['KRW'], isActive:true},
    {id:'kr_toss', name:'Toss Instant Transfer', type:'local_transfer', supportedCurrencies:['KRW'], isActive:true}
  ]},
  KW: { countryCode:'KW', countryName:'Kuwait', defaultCurrency:'KWD', paymentMethods:[
    {id:'kw_nbk', name:'National Bank of Kuwait', type:'bank', supportedCurrencies:['KWD'], isActive:true},
    {id:'kw_knet', name:'K-Net', type:'local_transfer', supportedCurrencies:['KWD'], isActive:true},
    {id:'kw_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['KWD'], isActive:true},
    {id:'kw_oman_net', name:'Oman Net / KWD Pay', type:'digital_wallet', supportedCurrencies:['KWD'], isActive:true},
    {id:'kw_cash', name:'Cash (KWD)', type:'cash', supportedCurrencies:['KWD'], isActive:true}
  ]},
  KY: { countryCode:'KY', countryName:'Cayman Islands', defaultCurrency:'KYD', paymentMethods:[
    {id:'ky_cibc', name:'CIBC FirstCaribbean', type:'bank', supportedCurrencies:['KYD','USD'], isActive:true},
    {id:'ky_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['KYD','USD'], isActive:true},
    {id:'ky_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'ky_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['KYD'], isActive:true},
    {id:'ky_cash', name:'Cash (KYD/USD)', type:'cash', supportedCurrencies:['KYD','USD'], isActive:true}
  ]},
  KZ: { countryCode:'KZ', countryName:'Kazakhstan', defaultCurrency:'KZT', paymentMethods:[
    {id:'kz_kaspi', name:'Kaspi.kz', type:'digital_wallet', supportedCurrencies:['KZT'], isActive:true},
    {id:'kz_halyk', name:'Halyk Bank', type:'bank', supportedCurrencies:['KZT'], isActive:true},
    {id:'kz_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['KZT'], isActive:true},
    {id:'kz_kaspi_pay', name:'Kaspi Pay / QR', type:'local_transfer', supportedCurrencies:['KZT'], isActive:true},
    {id:'kz_cash', name:'Cash (KZT)', type:'cash', supportedCurrencies:['KZT'], isActive:true}
  ]},
  LA: { countryCode:'LA', countryName:'Laos', defaultCurrency:'LAK', paymentMethods:[
    {id:'la_bcel', name:'BCEL', type:'bank', supportedCurrencies:['LAK'], isActive:true},
    {id:'la_bcel_one', name:'BCEL One', type:'digital_wallet', supportedCurrencies:['LAK'], isActive:true},
    {id:'la_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['LAK','USD'], isActive:true},
    {id:'la_lao_pay', name:'LaoPay', type:'local_transfer', supportedCurrencies:['LAK'], isActive:true},
    {id:'la_cash', name:'Cash (LAK)', type:'cash', supportedCurrencies:['LAK'], isActive:true}
  ]},
  LB: { countryCode:'LB', countryName:'Lebanon', defaultCurrency:'LBP', paymentMethods:[
    {id:'lb_bdl', name:'Bank of Lebanon / Local', type:'bank', supportedCurrencies:['LBP','USD'], isActive:true},
    {id:'lb_omla', name:'OMLA / Whish Money', type:'digital_wallet', supportedCurrencies:['LBP','USD'], isActive:true},
    {id:'lb_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'lb_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['LBP'], isActive:true},
    {id:'lb_cash', name:'Cash (LBP/USD)', type:'cash', supportedCurrencies:['LBP','USD'], isActive:true}
  ]},
  LC: { countryCode:'LC', countryName:'Saint Lucia', defaultCurrency:'XCD', paymentMethods:[
    {id:'lc_scotia', name:'Scotiabank', type:'bank', supportedCurrencies:['XCD'], isActive:true},
    {id:'lc_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XCD','USD'], isActive:true},
    {id:'lc_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'lc_transfer', name:'ECCU Transfer', type:'local_transfer', supportedCurrencies:['XCD'], isActive:true},
    {id:'lc_cash', name:'Cash (XCD)', type:'cash', supportedCurrencies:['XCD'], isActive:true}
  ]},
  LI: { countryCode:'LI', countryName:'Liechtenstein', defaultCurrency:'CHF', paymentMethods:[
    {id:'li_lgt', name:'LGT Bank', type:'bank', supportedCurrencies:['CHF'], isActive:true},
    {id:'li_twint', name:'TWINT', type:'digital_wallet', supportedCurrencies:['CHF'], isActive:true},
    {id:'li_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['CHF'], isActive:true},
    {id:'li_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['CHF','EUR'], isActive:true},
    {id:'li_cash', name:'Cash (CHF)', type:'cash', supportedCurrencies:['CHF'], isActive:true}
  ]},
  LK: { countryCode:'LK', countryName:'Sri Lanka', defaultCurrency:'LKR', paymentMethods:[
    {id:'lk_commercial', name:'Commercial Bank', type:'bank', supportedCurrencies:['LKR'], isActive:true},
    {id:'lk_dialog_pay', name:'Dialog Pay / Genie', type:'digital_wallet', supportedCurrencies:['LKR'], isActive:true},
    {id:'lk_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['LKR'], isActive:true},
    {id:'lk_just', name:'JustPay / CEFT', type:'local_transfer', supportedCurrencies:['LKR'], isActive:true},
    {id:'lk_cash', name:'Cash (LKR)', type:'cash', supportedCurrencies:['LKR'], isActive:true}
  ]},
  LR: { countryCode:'LR', countryName:'Liberia', defaultCurrency:'LRD', paymentMethods:[
    {id:'lr_ecobank', name:'Ecobank', type:'bank', supportedCurrencies:['LRD','USD'], isActive:true},
    {id:'lr_lonestar_money', name:'Lonestar Cell MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['LRD'], isActive:true},
    {id:'lr_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD','LRD'], isActive:true},
    {id:'lr_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['LRD'], isActive:true},
    {id:'lr_cash', name:'Cash (LRD/USD)', type:'cash', supportedCurrencies:['LRD','USD'], isActive:true}
  ]},
  LS: { countryCode:'LS', countryName:'Lesotho', defaultCurrency:'LSL', paymentMethods:[
    {id:'ls_standard', name:'Standard Bank Lesotho', type:'bank', supportedCurrencies:['LSL','ZAR'], isActive:true},
    {id:'ls_ecocash', name:'EcoCash / Vodacom M-Pesa', type:'digital_wallet', supportedCurrencies:['LSL'], isActive:true},
    {id:'ls_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['LSL','ZAR'], isActive:true},
    {id:'ls_sars', name:'SACU Transfer', type:'local_transfer', supportedCurrencies:['LSL'], isActive:true},
    {id:'ls_cash', name:'Cash (LSL/ZAR)', type:'cash', supportedCurrencies:['LSL','ZAR'], isActive:true}
  ]},
  LT: { countryCode:'LT', countryName:'Lithuania', defaultCurrency:'EUR', paymentMethods:[
    {id:'lt_swedbank', name:'Swedbank', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'lt_revolut', name:'Revolut', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'lt_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'lt_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'lt_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  LU: { countryCode:'LU', countryName:'Luxembourg', defaultCurrency:'EUR', paymentMethods:[
    {id:'lu_bcee', name:'BCEE', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'lu_paylib', name:'Paylib / Twint', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'lu_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'lu_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'lu_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  LV: { countryCode:'LV', countryName:'Latvia', defaultCurrency:'EUR', paymentMethods:[
    {id:'lv_swedbank', name:'Swedbank', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'lv_seb', name:'SEB Bank', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'lv_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'lv_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'lv_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  LY: { countryCode:'LY', countryName:'Libya', defaultCurrency:'LYD', paymentMethods:[
    {id:'ly_cbl', name:'Central Bank / Local', type:'bank', supportedCurrencies:['LYD'], isActive:true},
    {id:'ly_sadad', name:'Sadad / Libya Pay', type:'digital_wallet', supportedCurrencies:['LYD'], isActive:true},
    {id:'ly_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['LYD','USD'], isActive:true},
    {id:'ly_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['LYD'], isActive:true},
    {id:'ly_cash', name:'Cash (LYD/USD)', type:'cash', supportedCurrencies:['LYD','USD'], isActive:true}
  ]},
  MA: { countryCode:'MA', countryName:'Morocco', defaultCurrency:'MAD', paymentMethods:[
    {id:'ma_bcp', name:'Banque Centrale Populaire', type:'bank', supportedCurrencies:['MAD'], isActive:true},
    {id:'ma_cmi', name:'CMI Pay', type:'local_transfer', supportedCurrencies:['MAD'], isActive:true},
    {id:'ma_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MAD','EUR'], isActive:true},
    {id:'ma_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['MAD'], isActive:true},
    {id:'ma_cash', name:'Cash (MAD)', type:'cash', supportedCurrencies:['MAD'], isActive:true}
  ]},
  MC: { countryCode:'MC', countryName:'Monaco', defaultCurrency:'EUR', paymentMethods:[
    {id:'mc_credit_monegasque', name:'Crédit Monégasque', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'mc_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'mc_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'mc_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'mc_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  MD: { countryCode:'MD', countryName:'Moldova', defaultCurrency:'MDL', paymentMethods:[
    {id:'md_moldova_agro', name:'Moldova-Agroindbank', type:'bank', supportedCurrencies:['MDL'], isActive:true},
    {id:'md_runet', name:'Runet / MPay', type:'digital_wallet', supportedCurrencies:['MDL'], isActive:true},
    {id:'md_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MDL','EUR'], isActive:true},
    {id:'md_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['MDL'], isActive:true},
    {id:'md_cash', name:'Cash (MDL)', type:'cash', supportedCurrencies:['MDL'], isActive:true}
  ]},
  ME: { countryCode:'ME', countryName:'Montenegro', defaultCurrency:'EUR', paymentMethods:[
    {id:'me_nlbb', name:'NLB Banka', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'me_ipay', name:'iPay / CKB Pay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'me_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'me_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'me_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  MF: { countryCode:'MF', countryName:'Saint Martin', defaultCurrency:'EUR', paymentMethods:[
    {id:'mf_credit_agricole', name:'Crédit Agricole', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'mf_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'mf_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'mf_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'mf_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  MG: { countryCode:'MG', countryName:'Madagascar', defaultCurrency:'MGA', paymentMethods:[
    {id:'mg_bmo', name:'Bank of Madagascar', type:'bank', supportedCurrencies:['MGA'], isActive:true},
    {id:'mg_mvola', name:'MVola / Orange Money', type:'digital_wallet', supportedCurrencies:['MGA'], isActive:true},
    {id:'mg_africell', name:'Airtel Money', type:'digital_wallet', supportedCurrencies:['MGA'], isActive:true},
    {id:'mg_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MGA','EUR'], isActive:true},
    {id:'mg_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['MGA'], isActive:true}
  ]},
  MH: { countryCode:'MH', countryName:'Marshall Islands', defaultCurrency:'USD', paymentMethods:[
    {id:'mh_bank_hawaii', name:'Bank of Hawaii', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'mh_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'mh_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'mh_ach', name:'ACH Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'mh_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  MK: { countryCode:'MK', countryName:'North Macedonia', defaultCurrency:'MKD', paymentMethods:[
    {id:'mk_stopanska', name:'Stopanska Banka', type:'bank', supportedCurrencies:['MKD'], isActive:true},
    {id:'mk_paysera', name:'Paysera / MK Pay', type:'digital_wallet', supportedCurrencies:['MKD','EUR'], isActive:true},
    {id:'mk_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MKD','EUR'], isActive:true},
    {id:'mk_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['MKD'], isActive:true},
    {id:'mk_cash', name:'Cash (MKD)', type:'cash', supportedCurrencies:['MKD'], isActive:true}
  ]},
  ML: { countryCode:'ML', countryName:'Mali', defaultCurrency:'XOF', paymentMethods:[
    {id:'ml_bms', name:'Banque de Développement du Mali', type:'bank', supportedCurrencies:['XOF'], isActive:true},
    {id:'ml_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'ml_moov_money', name:'Moov Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'ml_visa', name:'Visa', type:'card', supportedCurrencies:['XOF','EUR'], isActive:true},
    {id:'ml_transfer', name:'WAEMU Transfer', type:'local_transfer', supportedCurrencies:['XOF'], isActive:true}
  ]},
  MM: { countryCode:'MM', countryName:'Myanmar', defaultCurrency:'MMK', paymentMethods:[
    {id:'mm_cbm', name:'CB Bank', type:'bank', supportedCurrencies:['MMK'], isActive:true},
    {id:'mm_wave_money', name:'Wave Money', type:'digital_wallet', supportedCurrencies:['MMK'], isActive:true},
    {id:'mm_kpay', name:'KBZPay', type:'digital_wallet', supportedCurrencies:['MMK'], isActive:true},
    {id:'mm_visa', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MMK','USD'], isActive:true},
    {id:'mm_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['MMK'], isActive:true}
  ]},
  MN: { countryCode:'MN', countryName:'Mongolia', defaultCurrency:'MNT', paymentMethods:[
    {id:'mn_khan', name:'Khan Bank', type:'bank', supportedCurrencies:['MNT'], isActive:true},
    {id:'mn_qpay', name:'QPay', type:'local_transfer', supportedCurrencies:['MNT'], isActive:true},
    {id:'mn_pay', name:'Pay / Mobicom Pay', type:'digital_wallet', supportedCurrencies:['MNT'], isActive:true},
    {id:'mn_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MNT'], isActive:true},
    {id:'mn_cash', name:'Cash (MNT)', type:'cash', supportedCurrencies:['MNT'], isActive:true}
  ]},
  MO: { countryCode:'MO', countryName:'Macao', defaultCurrency:'MOP', paymentMethods:[
    {id:'mo_bnu', name:'BNU', type:'bank', supportedCurrencies:['MOP','HKD'], isActive:true},
    {id:'mo_mpay', name:'MPay', type:'digital_wallet', supportedCurrencies:['MOP','HKD'], isActive:true},
    {id:'mo_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MOP','HKD'], isActive:true},
    {id:'mo_faps', name:'FAPS Transfer', type:'local_transfer', supportedCurrencies:['MOP'], isActive:true},
    {id:'mo_cash', name:'Cash (MOP/HKD)', type:'cash', supportedCurrencies:['MOP','HKD'], isActive:true}
  ]},
  MP: { countryCode:'MP', countryName:'Northern Mariana Islands', defaultCurrency:'USD', paymentMethods:[
    {id:'mp_bank_hawaii', name:'Bank of Hawaii', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'mp_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'mp_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'mp_ach', name:'ACH Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'mp_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  MQ: { countryCode:'MQ', countryName:'Martinique', defaultCurrency:'EUR', paymentMethods:[
    {id:'mq_credit_agricole', name:'Crédit Agricole', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'mq_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'mq_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'mq_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'mq_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  MR: { countryCode:'MR', countryName:'Mauritania', defaultCurrency:'MRU', paymentMethods:[
    {id:'mr_bcm', name:'Banque Centrale de Mauritanie', type:'bank', supportedCurrencies:['MRU'], isActive:true},
    {id:'mr_mauritel', name:'Mauritel Money', type:'digital_wallet', supportedCurrencies:['MRU'], isActive:true},
    {id:'mr_visa', name:'Visa', type:'card', supportedCurrencies:['MRU','EUR'], isActive:true},
    {id:'mr_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['MRU'], isActive:true},
    {id:'mr_cash', name:'Cash (MRU)', type:'cash', supportedCurrencies:['MRU'], isActive:true}
  ]},
  MS: { countryCode:'MS', countryName:'Montserrat', defaultCurrency:'XCD', paymentMethods:[
    {id:'ms_rbtt', name:'RBTT Bank', type:'bank', supportedCurrencies:['XCD'], isActive:true},
    {id:'ms_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XCD','USD'], isActive:true},
    {id:'ms_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'ms_ecs', name:'ECCU Transfer', type:'local_transfer', supportedCurrencies:['XCD'], isActive:true},
    {id:'ms_cash', name:'Cash (XCD)', type:'cash', supportedCurrencies:['XCD'], isActive:true}
  ]},
  MT: { countryCode:'MT', countryName:'Malta', defaultCurrency:'EUR', paymentMethods:[
    {id:'mt_bov', name:'Bank of Valletta', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'mt_sibs', name:'SIBS / Malta Pay', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'mt_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'mt_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'mt_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  MU: { countryCode:'MU', countryName:'Mauritius', defaultCurrency:'MUR', paymentMethods:[
    {id:'mu_mcb', name:'MCB Bank', type:'bank', supportedCurrencies:['MUR'], isActive:true},
    {id:'mu_juice', name:'Juice by MCB', type:'digital_wallet', supportedCurrencies:['MUR'], isActive:true},
    {id:'mu_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MUR'], isActive:true},
    {id:'mu_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['MUR'], isActive:true},
    {id:'mu_cash', name:'Cash (MUR)', type:'cash', supportedCurrencies:['MUR'], isActive:true}
  ]},
  MV: { countryCode:'MV', countryName:'Maldives', defaultCurrency:'MVR', paymentMethods:[
    {id:'mv_bml', name:'Bank of Maldives', type:'bank', supportedCurrencies:['MVR','USD'], isActive:true},
    {id:'mv_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MVR','USD'], isActive:true},
    {id:'mv_bml_pay', name:'BML Pay / MvPay', type:'digital_wallet', supportedCurrencies:['MVR'], isActive:true},
    {id:'mv_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['MVR'], isActive:true},
    {id:'mv_cash', name:'Cash (MVR/USD)', type:'cash', supportedCurrencies:['MVR','USD'], isActive:true}
  ]},
  MW: { countryCode:'MW', countryName:'Malawi', defaultCurrency:'MWK', paymentMethods:[
    {id:'mw_nbm', name:'National Bank of Malawi', type:'bank', supportedCurrencies:['MWK'], isActive:true},
    {id:'mw_tnm_mpamba', name:'TNM Mpamba', type:'digital_wallet', supportedCurrencies:['MWK'], isActive:true},
    {id:'mw_airtel_money', name:'Airtel Money', type:'digital_wallet', supportedCurrencies:['MWK'], isActive:true},
    {id:'mw_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MWK'], isActive:true},
    {id:'mw_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['MWK'], isActive:true}
  ]},
  MX: { countryCode:'MX', countryName:'Mexico', defaultCurrency:'MXN', paymentMethods:[
    {id:'mx_bbva', name:'BBVA México', type:'bank', supportedCurrencies:['MXN'], isActive:true},
    {id:'mx_spei', name:'SPEI', type:'local_transfer', supportedCurrencies:['MXN'], isActive:true},
    {id:'mx_mercadopago', name:'Mercado Pago / Clip', type:'digital_wallet', supportedCurrencies:['MXN'], isActive:true},
    {id:'mx_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MXN'], isActive:true},
    {id:'mx_oxxo', name:'OXXO Pay', type:'cash', supportedCurrencies:['MXN'], isActive:true}
  ]},
  MY: { countryCode:'MY', countryName:'Malaysia', defaultCurrency:'MYR', paymentMethods:[
    {id:'my_maybank', name:'Maybank', type:'bank', supportedCurrencies:['MYR'], isActive:true},
    {id:'my_tng', name:'Touch \'n Go eWallet', type:'digital_wallet', supportedCurrencies:['MYR'], isActive:true},
    {id:'my_grabpay', name:'GrabPay', type:'digital_wallet', supportedCurrencies:['MYR'], isActive:true},
    {id:'my_duitnow', name:'DuitNow QR / Transfer', type:'local_transfer', supportedCurrencies:['MYR'], isActive:true},
    {id:'my_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MYR'], isActive:true}
  ]},
  MZ: { countryCode:'MZ', countryName:'Mozambique', defaultCurrency:'MZN', paymentMethods:[
    {id:'mz_bim', name:'Banco Internacional de Moçambique', type:'bank', supportedCurrencies:['MZN'], isActive:true},
    {id:'mz_m_pesa', name:'M-Pesa', type:'digital_wallet', supportedCurrencies:['MZN'], isActive:true},
    {id:'mz_e_mola', name:'E-Mola', type:'digital_wallet', supportedCurrencies:['MZN'], isActive:true},
    {id:'mz_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['MZN'], isActive:true},
    {id:'mz_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['MZN'], isActive:true}
  ]},
  NA: { countryCode:'NA', countryName:'Namibia', defaultCurrency:'NAD', paymentMethods:[
    {id:'na_fnb', name:'First National Bank', type:'bank', supportedCurrencies:['NAD','ZAR'], isActive:true},
    {id:'na_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['NAD'], isActive:true},
    {id:'na_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['NAD','ZAR'], isActive:true},
    {id:'na_transfer', name:'SACU Transfer', type:'local_transfer', supportedCurrencies:['NAD'], isActive:true},
    {id:'na_cash', name:'Cash (NAD/ZAR)', type:'cash', supportedCurrencies:['NAD','ZAR'], isActive:true}
  ]},
  NC: { countryCode:'NC', countryName:'New Caledonia', defaultCurrency:'XPF', paymentMethods:[
    {id:'nc_bnc', name:'Banque de Nouvelle-Calédonie', type:'bank', supportedCurrencies:['XPF'], isActive:true},
    {id:'nc_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XPF','EUR'], isActive:true},
    {id:'nc_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR','USD'], isActive:true},
    {id:'nc_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['XPF'], isActive:true},
    {id:'nc_cash', name:'Cash (XPF)', type:'cash', supportedCurrencies:['XPF'], isActive:true}
  ]},
  NE: { countryCode:'NE', countryName:'Niger', defaultCurrency:'XOF', paymentMethods:[
    {id:'ne_ecobank', name:'Ecobank', type:'bank', supportedCurrencies:['XOF'], isActive:true},
    {id:'ne_moov_money', name:'Moov Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'ne_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'ne_visa', name:'Visa', type:'card', supportedCurrencies:['XOF','EUR'], isActive:true},
    {id:'ne_transfer', name:'WAEMU Transfer', type:'local_transfer', supportedCurrencies:['XOF'], isActive:true}
  ]},
  NF: { countryCode:'NF', countryName:'Norfolk Island', defaultCurrency:'AUD', paymentMethods:[
    {id:'nf_cba', name:'Commonwealth Bank', type:'bank', supportedCurrencies:['AUD'], isActive:true},
    {id:'nf_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AUD'], isActive:true},
    {id:'nf_payid', name:'PayID / Osko', type:'local_transfer', supportedCurrencies:['AUD'], isActive:true},
    {id:'nf_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['AUD'], isActive:true},
    {id:'nf_cash', name:'Cash (AUD)', type:'cash', supportedCurrencies:['AUD'], isActive:true}
  ]},
  NG: { countryCode:'NG', countryName:'Nigeria', defaultCurrency:'NGN', paymentMethods:[
    {id:'ng_gtbank', name:'GTBank', type:'bank', supportedCurrencies:['NGN'], isActive:true},
    {id:'ng_opay', name:'OPay', type:'digital_wallet', supportedCurrencies:['NGN'], isActive:true},
    {id:'ng_palm_pay', name:'PalmPay', type:'digital_wallet', supportedCurrencies:['NGN'], isActive:true},
    {id:'ng_nibs', name:'NIBSS Instant Payment', type:'local_transfer', supportedCurrencies:['NGN'], isActive:true},
    {id:'ng_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['NGN'], isActive:true}
  ]},
  NI: { countryCode:'NI', countryName:'Nicaragua', defaultCurrency:'NIO', paymentMethods:[
    {id:'ni_banic', name:'BANCIC', type:'bank', supportedCurrencies:['NIO','USD'], isActive:true},
    {id:'ni_tigo_money', name:'Tigo Money', type:'digital_wallet', supportedCurrencies:['NIO'], isActive:true},
    {id:'ni_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['NIO','USD'], isActive:true},
    {id:'ni_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['NIO'], isActive:true},
    {id:'ni_cash', name:'Cash (NIO/USD)', type:'cash', supportedCurrencies:['NIO','USD'], isActive:true}
  ]},
  NL: { countryCode:'NL', countryName:'Netherlands', defaultCurrency:'EUR', paymentMethods:[
    {id:'nl_ing', name:'ING Bank', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'nl_ideal', name:'iDEAL', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'nl_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'nl_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'nl_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true}
  ]},
  NO: { countryCode:'NO', countryName:'Norway', defaultCurrency:'NOK', paymentMethods:[
    {id:'no_dnb', name:'DNB', type:'bank', supportedCurrencies:['NOK'], isActive:true},
    {id:'no_vipps', name:'Vipps', type:'digital_wallet', supportedCurrencies:['NOK'], isActive:true},
    {id:'no_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['NOK'], isActive:true},
    {id:'no_bankaxept', name:'BankAxept', type:'local_transfer', supportedCurrencies:['NOK'], isActive:true},
    {id:'no_cash', name:'Cash (NOK)', type:'cash', supportedCurrencies:['NOK'], isActive:true}
  ]},
  NP: { countryCode:'NP', countryName:'Nepal', defaultCurrency:'NPR', paymentMethods:[
    {id:'np_nepal_bank', name:'Nepal Bank Limited', type:'bank', supportedCurrencies:['NPR'], isActive:true},
    {id:'np_esewa', name:'eSewa', type:'digital_wallet', supportedCurrencies:['NPR'], isActive:true},
    {id:'np_khalti', name:'Khalti', type:'digital_wallet', supportedCurrencies:['NPR'], isActive:true},
    {id:'np_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['NPR','USD'], isActive:true},
    {id:'np_nepal_pay', name:'Nepal Pay / ConnectIPS', type:'local_transfer', supportedCurrencies:['NPR'], isActive:true}
  ]},
  NR: { countryCode:'NR', countryName:'Nauru', defaultCurrency:'AUD', paymentMethods:[
    {id:'nr_bendigo', name:'Bendigo Bank', type:'bank', supportedCurrencies:['AUD'], isActive:true},
    {id:'nr_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['AUD'], isActive:true},
    {id:'nr_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['AUD','USD'], isActive:true},
    {id:'nr_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['AUD'], isActive:true},
    {id:'nr_cash', name:'Cash (AUD)', type:'cash', supportedCurrencies:['AUD'], isActive:true}
  ]},
  NU: { countryCode:'NU', countryName:'Niue', defaultCurrency:'NZD', paymentMethods:[
    {id:'nu_anz', name:'ANZ Bank', type:'bank', supportedCurrencies:['NZD'], isActive:true},
    {id:'nu_visa', name:'Visa', type:'card', supportedCurrencies:['NZD'], isActive:true},
    {id:'nu_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['NZD','USD'], isActive:true},
    {id:'nu_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['NZD'], isActive:true},
    {id:'nu_cash', name:'Cash (NZD)', type:'cash', supportedCurrencies:['NZD'], isActive:true}
  ]},
  NZ: { countryCode:'NZ', countryName:'New Zealand', defaultCurrency:'NZD', paymentMethods:[
    {id:'nz_asb', name:'ASB Bank', type:'bank', supportedCurrencies:['NZD'], isActive:true},
    {id:'nz_paymark', name:'PayMark / Eftpos', type:'local_transfer', supportedCurrencies:['NZD'], isActive:true},
    {id:'nz_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['NZD'], isActive:true},
    {id:'nz_afterpay', name:'Afterpay / Zip', type:'digital_wallet', supportedCurrencies:['NZD'], isActive:true},
    {id:'nz_apple_pay', name:'Apple/Google Pay', type:'digital_wallet', supportedCurrencies:['NZD'], isActive:true}
  ]},
  OM: { countryCode:'OM', countryName:'Oman', defaultCurrency:'OMR', paymentMethods:[
    {id:'om_bank_muscat', name:'Bank Muscat', type:'bank', supportedCurrencies:['OMR'], isActive:true},
    {id:'om_oman_net', name:'Oman Net', type:'local_transfer', supportedCurrencies:['OMR'], isActive:true},
    {id:'om_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['OMR'], isActive:true},
    {id:'om_pay', name:'Bank Muscat Pay / O-Pay', type:'digital_wallet', supportedCurrencies:['OMR'], isActive:true},
    {id:'om_cash', name:'Cash (OMR)', type:'cash', supportedCurrencies:['OMR'], isActive:true}
  ]},
  PA: { countryCode:'PA', countryName:'Panama', defaultCurrency:'PAB', paymentMethods:[
    {id:'pa_banco_general', name:'Banco General', type:'bank', supportedCurrencies:['PAB','USD'], isActive:true},
    {id:'pa_yappy', name:'Yappy', type:'digital_wallet', supportedCurrencies:['PAB','USD'], isActive:true},
    {id:'pa_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['PAB','USD'], isActive:true},
    {id:'pa_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['PAB'], isActive:true},
    {id:'pa_cash', name:'Cash (PAB/USD)', type:'cash', supportedCurrencies:['PAB','USD'], isActive:true}
  ]},
  PE: { countryCode:'PE', countryName:'Peru', defaultCurrency:'PEN', paymentMethods:[
    {id:'pe_bcp', name:'BCP', type:'bank', supportedCurrencies:['PEN'], isActive:true},
    {id:'pe_yape', name:'Yape / Plin', type:'digital_wallet', supportedCurrencies:['PEN'], isActive:true},
    {id:'pe_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['PEN'], isActive:true},
    {id:'pe_agentes', name:'Agentes BCP / Cash', type:'cash', supportedCurrencies:['PEN'], isActive:true},
    {id:'pe_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['PEN'], isActive:true}
  ]},
  PF: { countryCode:'PF', countryName:'French Polynesia', defaultCurrency:'XPF', paymentMethods:[
    {id:'pf_bnc', name:'Banque de Tahiti', type:'bank', supportedCurrencies:['XPF'], isActive:true},
    {id:'pf_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XPF','EUR'], isActive:true},
    {id:'pf_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR','USD'], isActive:true},
    {id:'pf_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['XPF'], isActive:true},
    {id:'pf_cash', name:'Cash (XPF)', type:'cash', supportedCurrencies:['XPF'], isActive:true}
  ]},
  PG: { countryCode:'PG', countryName:'Papua New Guinea', defaultCurrency:'PGK', paymentMethods:[
    {id:'pg_bsp', name:'BSP Bank', type:'bank', supportedCurrencies:['PGK'], isActive:true},
    {id:'pg_kina', name:'Kina Bank Pay', type:'digital_wallet', supportedCurrencies:['PGK'], isActive:true},
    {id:'pg_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['PGK'], isActive:true},
    {id:'pg_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['PGK'], isActive:true},
    {id:'pg_cash', name:'Cash (PGK)', type:'cash', supportedCurrencies:['PGK'], isActive:true}
  ]},
  PH: { countryCode:'PH', countryName:'Philippines', defaultCurrency:'PHP', paymentMethods:[
    {id:'ph_bdo', name:'BDO Unibank', type:'bank', supportedCurrencies:['PHP'], isActive:true},
    {id:'ph_gcash', name:'GCash', type:'digital_wallet', supportedCurrencies:['PHP'], isActive:true},
    {id:'ph_paymaya', name:'Maya', type:'digital_wallet', supportedCurrencies:['PHP'], isActive:true},
    {id:'ph_instapay', name:'InstaPay / PESONet', type:'local_transfer', supportedCurrencies:['PHP'], isActive:true},
    {id:'ph_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['PHP'], isActive:true}
  ]},
  PK: { countryCode:'PK', countryName:'Pakistan', defaultCurrency:'PKR', paymentMethods:[
    {id:'pk_hbl', name:'Habib Bank Limited', type:'bank', supportedCurrencies:['PKR'], isActive:true},
    {id:'pk_jazzcash', name:'JazzCash', type:'digital_wallet', supportedCurrencies:['PKR'], isActive:true},
    {id:'pk_easypaisa', name:'Easypaisa', type:'digital_wallet', supportedCurrencies:['PKR'], isActive:true},
    {id:'pk_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['PKR'], isActive:true},
    {id:'pk_raast', name:'Raast Instant Pay', type:'local_transfer', supportedCurrencies:['PKR'], isActive:true}
  ]},
  PL: { countryCode:'PL', countryName:'Poland', defaultCurrency:'PLN', paymentMethods:[
    {id:'pl_pkobp', name:'PKO BP', type:'bank', supportedCurrencies:['PLN'], isActive:true},
    {id:'pl_blik', name:'BLIK', type:'local_transfer', supportedCurrencies:['PLN'], isActive:true},
    {id:'pl_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['PLN'], isActive:true},
    {id:'pl_tpay', name:'TPay / Przelewy24', type:'digital_wallet', supportedCurrencies:['PLN'], isActive:true},
    {id:'pl_cash', name:'Cash (PLN)', type:'cash', supportedCurrencies:['PLN'], isActive:true}
  ]},
  PM: { countryCode:'PM', countryName:'Saint Pierre & Miquelon', defaultCurrency:'EUR', paymentMethods:[
    {id:'pm_credit_agricole', name:'Crédit Agricole', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'pm_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'pm_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'pm_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'pm_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  PN: { countryCode:'PN', countryName:'Pitcairn Islands', defaultCurrency:'NZD', paymentMethods:[
    {id:'pn_anz', name:'ANZ Bank', type:'bank', supportedCurrencies:['NZD'], isActive:true},
    {id:'pn_visa', name:'Visa', type:'card', supportedCurrencies:['NZD'], isActive:true},
    {id:'pn_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['NZD','USD'], isActive:true},
    {id:'pn_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['NZD'], isActive:true},
    {id:'pn_cash', name:'Cash (NZD)', type:'cash', supportedCurrencies:['NZD'], isActive:true}
  ]},
  PR: { countryCode:'PR', countryName:'Puerto Rico', defaultCurrency:'USD', paymentMethods:[
    {id:'pr_popular', name:'Popular Bank', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'pr_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'pr_paypal', name:'PayPal / Zelle', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'pr_ach', name:'ACH Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'pr_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  PS: { countryCode:'PS', countryName:'Palestine', defaultCurrency:'ILS', paymentMethods:[
    {id:'ps_bank_of_palestine', name:'Bank of Palestine', type:'bank', supportedCurrencies:['ILS','USD'], isActive:true},
    {id:'ps_jawwal', name:'Jawwal Pay', type:'digital_wallet', supportedCurrencies:['ILS'], isActive:true},
    {id:'ps_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['ILS','USD'], isActive:true},
    {id:'ps_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['ILS'], isActive:true},
    {id:'ps_cash', name:'Cash (ILS/USD)', type:'cash', supportedCurrencies:['ILS','USD'], isActive:true}
  ]},
  PT: { countryCode:'PT', countryName:'Portugal', defaultCurrency:'EUR', paymentMethods:[
    {id:'pt_cg', name:'Caixa Geral de Depósitos', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'pt_mbway', name:'MB WAY', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'pt_multibanco', name:'Multibanco / Referências', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'pt_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'pt_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  PW: { countryCode:'PW', countryName:'Palau', defaultCurrency:'USD', paymentMethods:[
    {id:'pw_bank_hawaii', name:'Bank of Hawaii', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'pw_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'pw_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'pw_ach', name:'ACH Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'pw_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  PY: { countryCode:'PY', countryName:'Paraguay', defaultCurrency:'PYG', paymentMethods:[
    {id:'py_bcp', name:'Banco Continental', type:'bank', supportedCurrencies:['PYG'], isActive:true},
    {id:'py_tigo_money', name:'Tigo Money', type:'digital_wallet', supportedCurrencies:['PYG'], isActive:true},
    {id:'py_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['PYG','USD'], isActive:true},
    {id:'py_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['PYG'], isActive:true},
    {id:'py_cash', name:'Cash (PYG/USD)', type:'cash', supportedCurrencies:['PYG','USD'], isActive:true}
  ]},
  QA: { countryCode:'QA', countryName:'Qatar', defaultCurrency:'QAR', paymentMethods:[
    {id:'qa_qnb', name:'QNB', type:'bank', supportedCurrencies:['QAR'], isActive:true},
    {id:'qa_fawri', name:'Fawri+', type:'local_transfer', supportedCurrencies:['QAR'], isActive:true},
    {id:'qa_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['QAR'], isActive:true},
    {id:'qa_qpay', name:'QPay / Ooredoo Money', type:'digital_wallet', supportedCurrencies:['QAR'], isActive:true},
    {id:'qa_cash', name:'Cash (QAR)', type:'cash', supportedCurrencies:['QAR'], isActive:true}
  ]},
  RE: { countryCode:'RE', countryName:'Réunion', defaultCurrency:'EUR', paymentMethods:[
    {id:'re_credit_agricole', name:'Crédit Agricole', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'re_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'re_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'re_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'re_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  RO: { countryCode:'RO', countryName:'Romania', defaultCurrency:'RON', paymentMethods:[
    {id:'ro_bcr', name:'BCR', type:'bank', supportedCurrencies:['RON'], isActive:true},
    {id:'ro_plati_ro', name:'Plati.ro', type:'local_transfer', supportedCurrencies:['RON'], isActive:true},
    {id:'ro_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['RON'], isActive:true},
    {id:'ro_revolut', name:'Revolut / BT Pay', type:'digital_wallet', supportedCurrencies:['RON'], isActive:true},
    {id:'ro_cash', name:'Cash (RON)', type:'cash', supportedCurrencies:['RON'], isActive:true}
  ]},
  RS: { countryCode:'RS', countryName:'Serbia', defaultCurrency:'RSD', paymentMethods:[
    {id:'rs_komercijalna', name:'Komercijalna Banka', type:'bank', supportedCurrencies:['RSD'], isActive:true},
    {id:'rs_ips', name:'IPS / Instant Payments', type:'local_transfer', supportedCurrencies:['RSD'], isActive:true},
    {id:'rs_visa_mc', name:'Visa/Mastercard / DinaCard', type:'card', supportedCurrencies:['RSD','EUR'], isActive:true},
    {id:'rs_mobile_pay', name:'MobilePay / mPay', type:'digital_wallet', supportedCurrencies:['RSD'], isActive:true},
    {id:'rs_cash', name:'Cash (RSD)', type:'cash', supportedCurrencies:['RSD'], isActive:true}
  ]},
  RU: { countryCode:'RU', countryName:'Russia', defaultCurrency:'RUB', paymentMethods:[
    {id:'ru_sber', name:'SberBank', type:'bank', supportedCurrencies:['RUB'], isActive:true},
    {id:'ru_sbp', name:'SBP (Fast Payment System)', type:'local_transfer', supportedCurrencies:['RUB'], isActive:true},
    {id:'ru_mir', name:'Mir Card', type:'card', supportedCurrencies:['RUB'], isActive:true},
    {id:'ru_yoomoney', name:'YooMoney / Qiwi', type:'digital_wallet', supportedCurrencies:['RUB'], isActive:true},
    {id:'ru_cash', name:'Cash (RUB)', type:'cash', supportedCurrencies:['RUB'], isActive:true}
  ]},
  RW: { countryCode:'RW', countryName:'Rwanda', defaultCurrency:'RWF', paymentMethods:[
    {id:'rw_bnr', name:'Banque National du Rwanda', type:'bank', supportedCurrencies:['RWF'], isActive:true},
    {id:'rw_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['RWF'], isActive:true},
    {id:'rw_airtel_money', name:'Airtel Money', type:'digital_wallet', supportedCurrencies:['RWF'], isActive:true},
    {id:'rw_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['RWF','USD'], isActive:true},
    {id:'rw_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['RWF'], isActive:true}
  ]},
  SA: { countryCode:'SA', countryName:'Saudi Arabia', defaultCurrency:'SAR', paymentMethods:[
    {id:'sa_al_rajhi', name:'Al Rajhi Bank', type:'bank', supportedCurrencies:['SAR'], isActive:true},
    {id:'sa_stc_pay', name:'STC Pay', type:'digital_wallet', supportedCurrencies:['SAR'], isActive:true},
    {id:'sa_mada', name:'MADA', type:'card', supportedCurrencies:['SAR'], isActive:true},
    {id:'sa_sarie', name:'SARIE Instant Transfer', type:'local_transfer', supportedCurrencies:['SAR'], isActive:true},
    {id:'sa_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['SAR'], isActive:true}
  ]},
  SB: { countryCode:'SB', countryName:'Solomon Islands', defaultCurrency:'SBD', paymentMethods:[
    {id:'sb_bsol', name:'Bank of South Pacific', type:'bank', supportedCurrencies:['SBD'], isActive:true},
    {id:'sb_visa', name:'Visa', type:'card', supportedCurrencies:['SBD','USD'], isActive:true},
    {id:'sb_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'sb_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['SBD'], isActive:true},
    {id:'sb_cash', name:'Cash (SBD)', type:'cash', supportedCurrencies:['SBD'], isActive:true}
  ]},
  SC: { countryCode:'SC', countryName:'Seychelles', defaultCurrency:'SCR', paymentMethods:[
    {id:'sc_nouvo', name:'Nouvo Banque', type:'bank', supportedCurrencies:['SCR'], isActive:true},
    {id:'sc_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['SCR','EUR'], isActive:true},
    {id:'sc_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR','USD'], isActive:true},
    {id:'sc_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['SCR'], isActive:true},
    {id:'sc_cash', name:'Cash (SCR)', type:'cash', supportedCurrencies:['SCR'], isActive:true}
  ]},
  SD: { countryCode:'SD', countryName:'Sudan', defaultCurrency:'SDG', paymentMethods:[
    {id:'sd_bos', name:'Bank of Sudan', type:'bank', supportedCurrencies:['SDG'], isActive:true},
    {id:'sd_zain_cash', name:'ZainCash / MTN MoMo', type:'digital_wallet', supportedCurrencies:['SDG'], isActive:true},
    {id:'sd_visa', name:'Visa (Limited)', type:'card', supportedCurrencies:['USD','SDG'], isActive:true},
    {id:'sd_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['SDG'], isActive:true},
    {id:'sd_cash', name:'Cash (SDG/USD)', type:'cash', supportedCurrencies:['SDG','USD'], isActive:true}
  ]},
  SE: { countryCode:'SE', countryName:'Sweden', defaultCurrency:'SEK', paymentMethods:[
    {id:'se_swedbank', name:'Swedbank', type:'bank', supportedCurrencies:['SEK'], isActive:true},
    {id:'se_swish', name:'Swish', type:'local_transfer', supportedCurrencies:['SEK'], isActive:true},
    {id:'se_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['SEK'], isActive:true},
    {id:'se_klarna', name:'Klarna / Revolut', type:'digital_wallet', supportedCurrencies:['SEK'], isActive:true},
    {id:'se_cash', name:'Cash (SEK)', type:'cash', supportedCurrencies:['SEK'], isActive:true}
  ]},
  SG: { countryCode:'SG', countryName:'Singapore', defaultCurrency:'SGD', paymentMethods:[
    {id:'sg_dbs', name:'DBS Bank', type:'bank', supportedCurrencies:['SGD'], isActive:true},
    {id:'sg_paynow', name:'PayNow', type:'local_transfer', supportedCurrencies:['SGD'], isActive:true},
    {id:'sg_grabpay', name:'GrabPay / ShopeePay', type:'digital_wallet', supportedCurrencies:['SGD'], isActive:true},
    {id:'sg_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['SGD'], isActive:true},
    {id:'sg_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['SGD'], isActive:true}
  ]},
  SH: { countryCode:'SH', countryName:'Saint Helena', defaultCurrency:'SHP', paymentMethods:[
    {id:'sh_santander', name:'Santander UK / SH Bank', type:'bank', supportedCurrencies:['SHP','GBP'], isActive:true},
    {id:'sh_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['SHP','GBP'], isActive:true},
    {id:'sh_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['GBP','USD'], isActive:true},
    {id:'sh_faster', name:'UK Faster Payments', type:'local_transfer', supportedCurrencies:['GBP'], isActive:true},
    {id:'sh_cash', name:'Cash (SHP/GBP)', type:'cash', supportedCurrencies:['SHP','GBP'], isActive:true}
  ]},
  SI: { countryCode:'SI', countryName:'Slovenia', defaultCurrency:'EUR', paymentMethods:[
    {id:'si_nl_banka', name:'NLB Banka', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'si_banka_si', name:'Banka.si / mBanka', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'si_visa_mc', name:'Visa/Mastercard / Maestro', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'si_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'si_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  SJ: { countryCode:'SJ', countryName:'Svalbard & Jan Mayen', defaultCurrency:'NOK', paymentMethods:[
    {id:'sj_dnb', name:'DNB', type:'bank', supportedCurrencies:['NOK'], isActive:true},
    {id:'sj_vipps', name:'Vipps', type:'digital_wallet', supportedCurrencies:['NOK'], isActive:true},
    {id:'sj_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['NOK'], isActive:true},
    {id:'sj_bankaxept', name:'BankAxept', type:'local_transfer', supportedCurrencies:['NOK'], isActive:true},
    {id:'sj_cash', name:'Cash (NOK)', type:'cash', supportedCurrencies:['NOK'], isActive:true}
  ]},
  SK: { countryCode:'SK', countryName:'Slovakia', defaultCurrency:'EUR', paymentMethods:[
    {id:'sk_slovenska', name:'Slovenská sporiteľňa', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'sk_tatra', name:'Tatra Pay / VÚB', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'sk_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'sk_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'sk_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  SL: { countryCode:'SL', countryName:'Sierra Leone', defaultCurrency:'SLL', paymentMethods:[
    {id:'sl_rockel', name:'Rokel Commercial Bank', type:'bank', supportedCurrencies:['SLL'], isActive:true},
    {id:'sl_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['SLL'], isActive:true},
    {id:'sl_africell', name:'Africell Money', type:'digital_wallet', supportedCurrencies:['SLL'], isActive:true},
    {id:'sl_visa', name:'Visa', type:'card', supportedCurrencies:['SLL','USD'], isActive:true},
    {id:'sl_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['SLL'], isActive:true}
  ]},
  SM: { countryCode:'SM', countryName:'San Marino', defaultCurrency:'EUR', paymentMethods:[
    {id:'sm_bsm', name:'Banca di San Marino', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'sm_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'sm_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'sm_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'sm_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  SN: { countryCode:'SN', countryName:'Senegal', defaultCurrency:'XOF', paymentMethods:[
    {id:'sn_ecobank', name:'Ecobank', type:'bank', supportedCurrencies:['XOF'], isActive:true},
    {id:'sn_orange_money', name:'Orange Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'sn_wave', name:'Wave', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'sn_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XOF','EUR'], isActive:true},
    {id:'sn_transfer', name:'WAEMU Transfer', type:'local_transfer', supportedCurrencies:['XOF'], isActive:true}
  ]},
  SO: { countryCode:'SO', countryName:'Somalia', defaultCurrency:'SOS', paymentMethods:[
    {id:'so_dahabshiil', name:'Dahabshiil Bank', type:'bank', supportedCurrencies:['SOS','USD'], isActive:true},
    {id:'so_zaad', name:'Zaad / Sahal', type:'digital_wallet', supportedCurrencies:['SOS'], isActive:true},
    {id:'so_evc_plus', name:'EVC Plus', type:'digital_wallet', supportedCurrencies:['SOS'], isActive:true},
    {id:'so_visa', name:'Visa (Limited)', type:'card', supportedCurrencies:['USD','SOS'], isActive:true},
    {id:'so_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['SOS'], isActive:true}
  ]},
  SR: { countryCode:'SR', countryName:'Suriname', defaultCurrency:'SRD', paymentMethods:[
    {id:'sr_dsb', name:'DSB Bank', type:'bank', supportedCurrencies:['SRD','USD'], isActive:true},
    {id:'sr_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['SRD','USD'], isActive:true},
    {id:'sr_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'sr_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['SRD'], isActive:true},
    {id:'sr_cash', name:'Cash (SRD/USD)', type:'cash', supportedCurrencies:['SRD','USD'], isActive:true}
  ]},
  SS: { countryCode:'SS', countryName:'South Sudan', defaultCurrency:'SSP', paymentMethods:[
    {id:'ss_boss', name:'Bank of South Sudan', type:'bank', supportedCurrencies:['SSP'], isActive:true},
    {id:'ss_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['SSP'], isActive:true},
    {id:'ss_zain_cash', name:'ZainCash', type:'digital_wallet', supportedCurrencies:['SSP'], isActive:true},
    {id:'ss_visa', name:'Visa', type:'card', supportedCurrencies:['SSP','USD'], isActive:true},
    {id:'ss_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['SSP'], isActive:true}
  ]},
  ST: { countryCode:'ST', countryName:'São Tomé & Príncipe', defaultCurrency:'STN', paymentMethods:[
    {id:'st_bstp', name:'Banco Internacional de STP', type:'bank', supportedCurrencies:['STN'], isActive:true},
    {id:'st_visa', name:'Visa', type:'card', supportedCurrencies:['STN','EUR'], isActive:true},
    {id:'st_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'st_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['STN'], isActive:true},
    {id:'st_cash', name:'Cash (STN/EUR)', type:'cash', supportedCurrencies:['STN','EUR'], isActive:true}
  ]},
  SV: { countryCode:'SV', countryName:'El Salvador', defaultCurrency:'USD', paymentMethods:[
    {id:'sv_banco_agricola', name:'Banco Agrícola', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'sv_chivo', name:'Chivo Wallet', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'sv_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'sv_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'sv_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  SX: { countryCode:'SX', countryName:'Sint Maarten', defaultCurrency:'ANG', paymentMethods:[
    {id:'sx_mcb', name:'MCB Bank', type:'bank', supportedCurrencies:['ANG','USD'], isActive:true},
    {id:'sx_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['ANG','USD'], isActive:true},
    {id:'sx_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'sx_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['ANG'], isActive:true},
    {id:'sx_cash', name:'Cash (ANG/USD)', type:'cash', supportedCurrencies:['ANG','USD'], isActive:true}
  ]},
  SY: { countryCode:'SY', countryName:'Syria', defaultCurrency:'SYP', paymentMethods:[
    {id:'sy_cbs', name:'Central Bank / Local', type:'bank', supportedCurrencies:['SYP'], isActive:true},
    {id:'sy_syriatel', name:'Syriatel Cash', type:'digital_wallet', supportedCurrencies:['SYP'], isActive:true},
    {id:'sy_visa', name:'Visa (Restricted)', type:'card', supportedCurrencies:['USD','EUR'], isActive:true},
    {id:'sy_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['SYP'], isActive:true},
    {id:'sy_cash', name:'Cash (SYP/USD)', type:'cash', supportedCurrencies:['SYP','USD'], isActive:true}
  ]},
  SZ: { countryCode:'SZ', countryName:'Eswatini', defaultCurrency:'SZL', paymentMethods:[
    {id:'sz_std', name:'Standard Bank Eswatini', type:'bank', supportedCurrencies:['SZL','ZAR'], isActive:true},
    {id:'sz_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['SZL'], isActive:true},
    {id:'sz_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['SZL','ZAR'], isActive:true},
    {id:'sz_transfer', name:'SACU Transfer', type:'local_transfer', supportedCurrencies:['SZL'], isActive:true},
    {id:'sz_cash', name:'Cash (SZL/ZAR)', type:'cash', supportedCurrencies:['SZL','ZAR'], isActive:true}
  ]},
  TC: { countryCode:'TC', countryName:'Turks & Caicos', defaultCurrency:'USD', paymentMethods:[
    {id:'tc_rbc', name:'RBC Royal Bank', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'tc_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'tc_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'tc_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'tc_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  TD: { countryCode:'TD', countryName:'Chad', defaultCurrency:'XAF', paymentMethods:[
    {id:'td_bceae', name:'BCEAE / Local Banks', type:'bank', supportedCurrencies:['XAF'], isActive:true},
    {id:'td_airtel_money', name:'Airtel Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'td_moov_money', name:'Moov Money', type:'digital_wallet', supportedCurrencies:['XAF'], isActive:true},
    {id:'td_visa', name:'Visa', type:'card', supportedCurrencies:['XAF','EUR'], isActive:true},
    {id:'td_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['XAF'], isActive:true}
  ]},
  TF: { countryCode:'TF', countryName:'French Southern Territories', defaultCurrency:'EUR', paymentMethods:[
    {id:'tf_credit_agricole', name:'Crédit Agricole', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'tf_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'tf_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'tf_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'tf_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  TG: { countryCode:'TG', countryName:'Togo', defaultCurrency:'XOF', paymentMethods:[
    {id:'tg_bceao', name:'BCEAO', type:'bank', supportedCurrencies:['XOF'], isActive:true},
    {id:'tg_moov_money', name:'Moov Money', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'tg_flooz', name:'Flooz', type:'digital_wallet', supportedCurrencies:['XOF'], isActive:true},
    {id:'tg_visa', name:'Visa', type:'card', supportedCurrencies:['XOF','EUR'], isActive:true},
    {id:'tg_transfer', name:'WAEMU Transfer', type:'local_transfer', supportedCurrencies:['XOF'], isActive:true}
  ]},
  TH: { countryCode:'TH', countryName:'Thailand', defaultCurrency:'THB', paymentMethods:[
    {id:'th_krungthai', name:'Krungthai Bank', type:'bank', supportedCurrencies:['THB'], isActive:true},
    {id:'th_promptpay', name:'PromptPay', type:'local_transfer', supportedCurrencies:['THB'], isActive:true},
    {id:'th_truemoney', name:'TrueMoney Wallet', type:'digital_wallet', supportedCurrencies:['THB'], isActive:true},
    {id:'th_line_pay', name:'LINE Pay', type:'digital_wallet', supportedCurrencies:['THB'], isActive:true},
    {id:'th_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['THB'], isActive:true}
  ]},
  TJ: { countryCode:'TJ', countryName:'Tajikistan', defaultCurrency:'TJS', paymentMethods:[
    {id:'tj_spitamen', name:'Spitamen Bank', type:'bank', supportedCurrencies:['TJS'], isActive:true},
    {id:'tj_alif_mobili', name:'Alif Mobi', type:'digital_wallet', supportedCurrencies:['TJS'], isActive:true},
    {id:'tj_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['TJS','USD'], isActive:true},
    {id:'tj_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['TJS'], isActive:true},
    {id:'tj_cash', name:'Cash (TJS)', type:'cash', supportedCurrencies:['TJS'], isActive:true}
  ]},
  TK: { countryCode:'TK', countryName:'Tokelau', defaultCurrency:'NZD', paymentMethods:[
    {id:'tk_anz', name:'ANZ Bank', type:'bank', supportedCurrencies:['NZD'], isActive:true},
    {id:'tk_visa', name:'Visa', type:'card', supportedCurrencies:['NZD'], isActive:true},
    {id:'tk_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['NZD','USD'], isActive:true},
    {id:'tk_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['NZD'], isActive:true},
    {id:'tk_cash', name:'Cash (NZD)', type:'cash', supportedCurrencies:['NZD'], isActive:true}
  ]},
  TL: { countryCode:'TL', countryName:'Timor-Leste', defaultCurrency:'USD', paymentMethods:[
    {id:'tl_bntl', name:'Banco Nacional de Timor-Leste', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'tl_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'tl_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'tl_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'tl_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  TM: { countryCode:'TM', countryName:'Turkmenistan', defaultCurrency:'TMT', paymentMethods:[
    {id:'tm_cb', name:'Central Bank / Türkmenbaşy', type:'bank', supportedCurrencies:['TMT'], isActive:true},
    {id:'tm_altyn_asyr', name:'Altyn Asyr Pay', type:'digital_wallet', supportedCurrencies:['TMT'], isActive:true},
    {id:'tm_visa', name:'Visa (Limited)', type:'card', supportedCurrencies:['USD','TMT'], isActive:true},
    {id:'tm_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['TMT'], isActive:true},
    {id:'tm_cash', name:'Cash (TMT)', type:'cash', supportedCurrencies:['TMT'], isActive:true}
  ]},
  TN: { countryCode:'TN', countryName:'Tunisia', defaultCurrency:'TND', paymentMethods:[
    {id:'tn_biat', name:'BIAT', type:'bank', supportedCurrencies:['TND'], isActive:true},
    {id:'tn_d17', name:'D17', type:'digital_wallet', supportedCurrencies:['TND'], isActive:true},
    {id:'tn_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['TND','EUR'], isActive:true},
    {id:'tn_flouci', name:'Flouci / e-Dinar', type:'local_transfer', supportedCurrencies:['TND'], isActive:true},
    {id:'tn_cash', name:'Cash (TND)', type:'cash', supportedCurrencies:['TND'], isActive:true}
  ]},
  TO: { countryCode:'TO', countryName:'Tonga', defaultCurrency:'TOP', paymentMethods:[
    {id:'to_nbt', name:'National Bank of Tonga', type:'bank', supportedCurrencies:['TOP'], isActive:true},
    {id:'to_visa', name:'Visa', type:'card', supportedCurrencies:['TOP','USD'], isActive:true},
    {id:'to_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'to_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['TOP'], isActive:true},
    {id:'to_cash', name:'Cash (TOP)', type:'cash', supportedCurrencies:['TOP'], isActive:true}
  ]},
  TR: { countryCode:'TR', countryName:'Turkey', defaultCurrency:'TRY', paymentMethods:[
    {id:'tr_isbank', name:'İşbank', type:'bank', supportedCurrencies:['TRY'], isActive:true},
    {id:'tr_fast', name:'FAST / QR Transfer', type:'local_transfer', supportedCurrencies:['TRY'], isActive:true},
    {id:'tr_paycell', name:'PayCell / Papara', type:'digital_wallet', supportedCurrencies:['TRY'], isActive:true},
    {id:'tr_troy', name:'Troy / Visa/Mastercard', type:'card', supportedCurrencies:['TRY'], isActive:true},
    {id:'tr_cash', name:'Cash (TRY)', type:'cash', supportedCurrencies:['TRY'], isActive:true}
  ]},
  TT: { countryCode:'TT', countryName:'Trinidad & Tobago', defaultCurrency:'TTD', paymentMethods:[
    {id:'tt_rbc', name:'RBC Royal Bank', type:'bank', supportedCurrencies:['TTD'], isActive:true},
    {id:'tt_link', name:'LINKTT / Digicel Money', type:'digital_wallet', supportedCurrencies:['TTD'], isActive:true},
    {id:'tt_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['TTD','USD'], isActive:true},
    {id:'tt_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['TTD'], isActive:true},
    {id:'tt_cash', name:'Cash (TTD/USD)', type:'cash', supportedCurrencies:['TTD','USD'], isActive:true}
  ]},
  TV: { countryCode:'TV', countryName:'Tuvalu', defaultCurrency:'AUD', paymentMethods:[
    {id:'tv_cba', name:'Commonwealth Bank', type:'bank', supportedCurrencies:['AUD'], isActive:true},
    {id:'tv_visa', name:'Visa', type:'card', supportedCurrencies:['AUD'], isActive:true},
    {id:'tv_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['AUD','USD'], isActive:true},
    {id:'tv_payid', name:'PayID / Osko', type:'local_transfer', supportedCurrencies:['AUD'], isActive:true},
    {id:'tv_cash', name:'Cash (AUD)', type:'cash', supportedCurrencies:['AUD'], isActive:true}
  ]},
  TW: { countryCode:'TW', countryName:'Taiwan', defaultCurrency:'TWD', paymentMethods:[
    {id:'tw_ctbc', name:'CTBC Bank', type:'bank', supportedCurrencies:['TWD'], isActive:true},
    {id:'tw_jko', name:'JKO Pay / LINE Pay', type:'digital_wallet', supportedCurrencies:['TWD'], isActive:true},
    {id:'tw_twqr', name:'TWQR', type:'local_transfer', supportedCurrencies:['TWD'], isActive:true},
    {id:'tw_visa_mc', name:'Visa/Mastercard / UnionPay', type:'card', supportedCurrencies:['TWD'], isActive:true},
    {id:'tw_cash', name:'Cash (TWD)', type:'cash', supportedCurrencies:['TWD'], isActive:true}
  ]},
  TZ: { countryCode:'TZ', countryName:'Tanzania', defaultCurrency:'TZS', paymentMethods:[
    {id:'tz_nmb', name:'NMB Bank', type:'bank', supportedCurrencies:['TZS'], isActive:true},
    {id:'tz_m_pesa', name:'M-Pesa', type:'digital_wallet', supportedCurrencies:['TZS'], isActive:true},
    {id:'tz_tigo_pesa', name:'Tigo Pesa', type:'digital_wallet', supportedCurrencies:['TZS'], isActive:true},
    {id:'tz_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['TZS'], isActive:true},
    {id:'tz_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['TZS'], isActive:true}
  ]},
  UA: { countryCode:'UA', countryName:'Ukraine', defaultCurrency:'UAH', paymentMethods:[
    {id:'ua_privatbank', name:'PrivatBank', type:'bank', supportedCurrencies:['UAH'], isActive:true},
    {id:'ua_monobank', name:'Monobank', type:'digital_wallet', supportedCurrencies:['UAH'], isActive:true},
    {id:'ua_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['UAH'], isActive:true},
    {id:'ua_p24', name:'Portmone / P24', type:'local_transfer', supportedCurrencies:['UAH'], isActive:true},
    {id:'ua_cash', name:'Cash (UAH)', type:'cash', supportedCurrencies:['UAH'], isActive:true}
  ]},
  UG: { countryCode:'UG', countryName:'Uganda', defaultCurrency:'UGX', paymentMethods:[
    {id:'ug_stanbic', name:'Stanbic Bank', type:'bank', supportedCurrencies:['UGX'], isActive:true},
    {id:'ug_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['UGX'], isActive:true},
    {id:'ug_airtel_money', name:'Airtel Money', type:'digital_wallet', supportedCurrencies:['UGX'], isActive:true},
    {id:'ug_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['UGX'], isActive:true},
    {id:'ug_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['UGX'], isActive:true}
  ]},
  UM: { countryCode:'UM', countryName:'US Minor Outlying Islands', defaultCurrency:'USD', paymentMethods:[
    {id:'um_bofa', name:'Bank of America', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'um_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'um_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'um_ach', name:'ACH Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'um_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  US: { countryCode:'US', countryName:'United States', defaultCurrency:'USD', paymentMethods:[
    {id:'us_chase', name:'JPMorgan Chase', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'us_boa', name:'Bank of America', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'us_visa_mc', name:'Visa / Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'us_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'us_venmo', name:'Venmo', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true}
  ]},
  UY: { countryCode:'UY', countryName:'Uruguay', defaultCurrency:'UYU', paymentMethods:[
    {id:'uy_brou', name:'BROU', type:'bank', supportedCurrencies:['UYU'], isActive:true},
    {id:'uy_bancada', name:'Bancada / Prex', type:'digital_wallet', supportedCurrencies:['UYU'], isActive:true},
    {id:'uy_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['UYU'], isActive:true},
    {id:'uy_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['UYU'], isActive:true},
    {id:'uy_cash', name:'Cash (UYU)', type:'cash', supportedCurrencies:['UYU'], isActive:true}
  ]},
  UZ: { countryCode:'UZ', countryName:'Uzbekistan', defaultCurrency:'UZS', paymentMethods:[
    {id:'uz_ipak', name:'Ipak Yuli Bank', type:'bank', supportedCurrencies:['UZS'], isActive:true},
    {id:'uz_payme', name:'Payme / Click', type:'digital_wallet', supportedCurrencies:['UZS'], isActive:true},
    {id:'uz_visa_mc', name:'Visa/Mastercard / UzCard', type:'card', supportedCurrencies:['UZS'], isActive:true},
    {id:'uz_humo', name:'Humo / Local Transfer', type:'local_transfer', supportedCurrencies:['UZS'], isActive:true},
    {id:'uz_cash', name:'Cash (UZS)', type:'cash', supportedCurrencies:['UZS'], isActive:true}
  ]},
  VA: { countryCode:'VA', countryName:'Vatican City', defaultCurrency:'EUR', paymentMethods:[
    {id:'va_ior', name:'IOR / Local Bank', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'va_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'va_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'va_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'va_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  VC: { countryCode:'VC', countryName:'Saint Vincent & Grenadines', defaultCurrency:'XCD', paymentMethods:[
    {id:'vc_ncb', name:'NCB Bank', type:'bank', supportedCurrencies:['XCD'], isActive:true},
    {id:'vc_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XCD','USD'], isActive:true},
    {id:'vc_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'vc_ecs', name:'ECCU Transfer', type:'local_transfer', supportedCurrencies:['XCD'], isActive:true},
    {id:'vc_cash', name:'Cash (XCD)', type:'cash', supportedCurrencies:['XCD'], isActive:true}
  ]},
  VE: { countryCode:'VE', countryName:'Venezuela', defaultCurrency:'VES', paymentMethods:[
    {id:'ve_banesco', name:'Banesco', type:'bank', supportedCurrencies:['VES','USD'], isActive:true},
    {id:'ve_punto', name:'Pago Móvil', type:'local_transfer', supportedCurrencies:['VES'], isActive:true},
    {id:'ve_binance', name:'Binance Pay / Zelle', type:'digital_wallet', supportedCurrencies:['USD','VES'], isActive:true},
    {id:'ve_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'ve_cash', name:'Cash (VES/USD)', type:'cash', supportedCurrencies:['VES','USD'], isActive:true}
  ]},
  VG: { countryCode:'VG', countryName:'British Virgin Islands', defaultCurrency:'USD', paymentMethods:[
    {id:'vg_rbc', name:'RBC Royal Bank', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'vg_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'vg_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'vg_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'vg_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  VI: { countryCode:'VI', countryName:'US Virgin Islands', defaultCurrency:'USD', paymentMethods:[
    {id:'vi_bofa', name:'Bank of America', type:'bank', supportedCurrencies:['USD'], isActive:true},
    {id:'vi_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD'], isActive:true},
    {id:'vi_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'vi_ach', name:'ACH Transfer', type:'local_transfer', supportedCurrencies:['USD'], isActive:true},
    {id:'vi_cash', name:'Cash (USD)', type:'cash', supportedCurrencies:['USD'], isActive:true}
  ]},
  VN: { countryCode:'VN', countryName:'Vietnam', defaultCurrency:'VND', paymentMethods:[
    {id:'vn_vcb', name:'Vietcombank', type:'bank', supportedCurrencies:['VND'], isActive:true},
    {id:'vn_momo', name:'MoMo', type:'digital_wallet', supportedCurrencies:['VND'], isActive:true},
    {id:'vn_zalopay', name:'ZaloPay', type:'digital_wallet', supportedCurrencies:['VND'], isActive:true},
    {id:'vn_napas', name:'NAPAS / QR Transfer', type:'local_transfer', supportedCurrencies:['VND'], isActive:true},
    {id:'vn_visa_mc', name:'Visa/Mastercard / JCB', type:'card', supportedCurrencies:['VND'], isActive:true}
  ]},
  VU: { countryCode:'VU', countryName:'Vanuatu', defaultCurrency:'VUV', paymentMethods:[
    {id:'vu_nbv', name:'National Bank of Vanuatu', type:'bank', supportedCurrencies:['VUV'], isActive:true},
    {id:'vu_visa', name:'Visa', type:'card', supportedCurrencies:['VUV','USD'], isActive:true},
    {id:'vu_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'vu_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['VUV'], isActive:true},
    {id:'vu_cash', name:'Cash (VUV)', type:'cash', supportedCurrencies:['VUV'], isActive:true}
  ]},
  WF: { countryCode:'WF', countryName:'Wallis & Futuna', defaultCurrency:'XPF', paymentMethods:[
    {id:'wf_bnc', name:'Banque de Wallis et Futuna', type:'bank', supportedCurrencies:['XPF'], isActive:true},
    {id:'wf_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['XPF','EUR'], isActive:true},
    {id:'wf_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR','USD'], isActive:true},
    {id:'wf_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['XPF'], isActive:true},
    {id:'wf_cash', name:'Cash (XPF)', type:'cash', supportedCurrencies:['XPF'], isActive:true}
  ]},
  WS: { countryCode:'WS', countryName:'Samoa', defaultCurrency:'WST', paymentMethods:[
    {id:'ws_bsp', name:'BSP Samoa', type:'bank', supportedCurrencies:['WST'], isActive:true},
    {id:'ws_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['WST'], isActive:true},
    {id:'ws_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['USD'], isActive:true},
    {id:'ws_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['WST'], isActive:true},
    {id:'ws_cash', name:'Cash (WST)', type:'cash', supportedCurrencies:['WST'], isActive:true}
  ]},
  YE: { countryCode:'YE', countryName:'Yemen', defaultCurrency:'YER', paymentMethods:[
    {id:'ye_cby', name:'Central Bank / Local', type:'bank', supportedCurrencies:['YER'], isActive:true},
    {id:'ye_kuraimi', name:'Kuraimi / Yemeni Mobile Money', type:'digital_wallet', supportedCurrencies:['YER'], isActive:true},
    {id:'ye_visa', name:'Visa (Limited)', type:'card', supportedCurrencies:['USD','YER'], isActive:true},
    {id:'ye_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['YER'], isActive:true},
    {id:'ye_cash', name:'Cash (YER/USD)', type:'cash', supportedCurrencies:['YER','USD'], isActive:true}
  ]},
  YT: { countryCode:'YT', countryName:'Mayotte', defaultCurrency:'EUR', paymentMethods:[
    {id:'yt_credit_agricole', name:'Crédit Agricole', type:'bank', supportedCurrencies:['EUR'], isActive:true},
    {id:'yt_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['EUR'], isActive:true},
    {id:'yt_paypal', name:'PayPal', type:'digital_wallet', supportedCurrencies:['EUR'], isActive:true},
    {id:'yt_sepa', name:'SEPA Transfer', type:'local_transfer', supportedCurrencies:['EUR'], isActive:true},
    {id:'yt_cash', name:'Cash (EUR)', type:'cash', supportedCurrencies:['EUR'], isActive:true}
  ]},
  ZA: { countryCode:'ZA', countryName:'South Africa', defaultCurrency:'ZAR', paymentMethods:[
    {id:'za_fnb', name:'First National Bank', type:'bank', supportedCurrencies:['ZAR'], isActive:true},
    {id:'za_eft', name:'EFT / SnapScan', type:'local_transfer', supportedCurrencies:['ZAR'], isActive:true},
    {id:'za_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['ZAR'], isActive:true},
    {id:'za_capitec', name:'Capitec Pay', type:'digital_wallet', supportedCurrencies:['ZAR'], isActive:true},
    {id:'za_cash', name:'Cash (ZAR)', type:'cash', supportedCurrencies:['ZAR'], isActive:true}
  ]},
  ZM: { countryCode:'ZM', countryName:'Zambia', defaultCurrency:'ZMW', paymentMethods:[
    {id:'zm_zanaco', name:'Zanaco', type:'bank', supportedCurrencies:['ZMW'], isActive:true},
    {id:'zm_mtn_momo', name:'MTN Mobile Money', type:'digital_wallet', supportedCurrencies:['ZMW'], isActive:true},
    {id:'zm_airtel_money', name:'Airtel Money', type:'digital_wallet', supportedCurrencies:['ZMW'], isActive:true},
    {id:'zm_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['ZMW'], isActive:true},
    {id:'zm_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['ZMW'], isActive:true}
  ]},
  ZW: { countryCode:'ZW', countryName:'Zimbabwe', defaultCurrency:'ZWL', paymentMethods:[
    {id:'zw_cbz', name:'CBZ Bank', type:'bank', supportedCurrencies:['ZWL','USD'], isActive:true},
    {id:'zw_ecocash', name:'EcoCash', type:'digital_wallet', supportedCurrencies:['ZWL'], isActive:true},
    {id:'zw_innbucks', name:'InnBucks', type:'digital_wallet', supportedCurrencies:['ZWL','USD'], isActive:true},
    {id:'zw_visa_mc', name:'Visa/Mastercard', type:'card', supportedCurrencies:['USD','ZWL'], isActive:true},
    {id:'zw_transfer', name:'Local Bank Transfer', type:'local_transfer', supportedCurrencies:['ZWL'], isActive:true}
  ]},
};